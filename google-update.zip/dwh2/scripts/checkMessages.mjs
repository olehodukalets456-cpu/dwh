import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

/**
 * Fails when the locales drift apart. TypeScript only types keys against `en`
 * (see src/types/messages.d.ts), so a key missing from ua/ru compiles fine and
 * only shows up as a MISSING_MESSAGE at runtime — this closes that gap.
 */
const MESSAGES_DIR = "messages";
const REFERENCE_LOCALE = "en";

const flatten = (value, prefix = "") =>
  Object.entries(value).flatMap(([key, child]) => {
    const path = prefix ? `${prefix}.${key}` : key;
    return child !== null && typeof child === "object" ? flatten(child, path) : [path];
  });

const readNamespace = (locale, file) => JSON.parse(readFileSync(join(MESSAGES_DIR, locale, file), "utf8"));

const locales = readdirSync(MESSAGES_DIR, { withFileTypes: true })
  .filter((entry) => entry.isDirectory())
  .map((entry) => entry.name);

const referenceFiles = readdirSync(join(MESSAGES_DIR, REFERENCE_LOCALE)).filter((file) => file.endsWith(".json"));
const problems = [];

for (const locale of locales.filter((locale) => locale !== REFERENCE_LOCALE)) {
  const files = new Set(readdirSync(join(MESSAGES_DIR, locale)).filter((file) => file.endsWith(".json")));

  for (const file of referenceFiles) {
    if (!files.has(file)) {
      problems.push(`${locale}/${file} — namespace missing`);
      continue;
    }
    files.delete(file);

    const expected = new Set(flatten(readNamespace(REFERENCE_LOCALE, file)));
    const actual = new Set(flatten(readNamespace(locale, file)));

    for (const key of expected) if (!actual.has(key)) problems.push(`${locale}/${file} — missing key "${key}"`);
    for (const key of actual) if (!expected.has(key)) problems.push(`${locale}/${file} — extra key "${key}"`);
  }

  for (const file of files) problems.push(`${locale}/${file} — namespace has no ${REFERENCE_LOCALE} counterpart`);
}

if (problems.length > 0) {
  console.error(`Message catalogs are out of sync (${problems.length}):`);
  for (const problem of problems) console.error(`  - ${problem}`);
  process.exit(1);
}

console.log(`Message catalogs in sync — ${referenceFiles.length} namespaces × ${locales.length} locales.`);
