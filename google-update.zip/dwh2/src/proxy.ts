import createMiddleware from "next-intl/middleware";
import { routing } from "@/i18n/routing";

// Next 16 renamed the `middleware` file convention to `proxy`; next-intl still ships the
// handler factory under its original name. Detects the locale and rewrites/redirects accordingly.
export default createMiddleware(routing);

export const config = {
  // Skip Next internals and anything with a file extension (static assets); everything else is locale-routed.
  matcher: ["/((?!api|_next|_vercel|.*\\..*).*)"],
};
