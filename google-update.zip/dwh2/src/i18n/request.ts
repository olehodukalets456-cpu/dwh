import { hasLocale } from "next-intl";
import { getRequestConfig } from "next-intl/server";
import { routing } from "./routing";

/**
 * One namespace per landing section, so sections can be built in parallel without contending
 * on a single catalog file. Adding one = create the JSON in all locales, list it here, and
 * add it to `Messages` in `src/types/messages.d.ts`.
 */
const NAMESPACES = [
  "common",
  "navigation",
  "footer",
  "landing-hero",
  "landing-advantages",
  "landing-compatibility",
  "landing-profit",
  "landing-pricing",
  "landing-faq",
  "landing-cta",
  "legal-terms",
  "free-domain-popup",
] as const;

export default getRequestConfig(async ({ requestLocale }) => {
  const requested = await requestLocale;
  const locale = hasLocale(routing.locales, requested) ? requested : routing.defaultLocale;

  const namespaces = await Promise.all(
    NAMESPACES.map(async (ns) => [ns, (await import(`../../messages/${locale}/${ns}.json`)).default] as const),
  );

  return {
    locale,
    messages: Object.fromEntries(namespaces),
  };
});
