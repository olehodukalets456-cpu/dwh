import { createNavigation } from "next-intl/navigation";
import { routing } from "./routing";

// Locale-aware replacements for Next's navigation APIs — always use these, never next/link/next/navigation directly.
export const { Link, redirect, usePathname, useRouter, getPathname } = createNavigation(routing);
