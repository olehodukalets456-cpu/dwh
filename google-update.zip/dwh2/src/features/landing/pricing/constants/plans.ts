import type { PricingPlan } from "../types";

/**
 * `as const satisfies` keeps literal `nameKey`/`featureKeys` types so a missing catalog key
 * fails to compile. The bulk plan's `priceAmount: null` is intentional — genuinely quote-based.
 */
export const PRICING_PLANS = [
  {
    id: "standard",
    nameKey: "plans.standard.name",
    subTitle: "plans.standard.subTitle",
    descriptionKey: "plans.standard.description",
    priceAmount: 5,
    originalPriceAmount: 15,
    currency: "USD",
    unitKey: "plans.standard.unit",
    featureKeys: [
      "plans.standard.features.verifiedHistory",
      "plans.standard.features.fullReport",
      "plans.standard.features.instantDelivery",
      "plans.standard.features.support",
    ],
    ctaKey: "plans.standard.cta",
    isFeatured: true,
  },
  {
    id: "bulk",
    nameKey: "plans.bulk.name",
    subTitle: "plans.bulk.subTitle",
    descriptionKey: "plans.bulk.description",
    priceAmount: null,
    currency: "USD",
    featureKeys: [
      "plans.bulk.features.volumeDiscount",
      "plans.bulk.features.personalManager",
      "plans.bulk.features.prioritySupport",
      "plans.bulk.features.customTerms",
    ],
    ctaKey: "plans.bulk.cta",
    isFeatured: false,
  },
] as const satisfies readonly PricingPlan[];
