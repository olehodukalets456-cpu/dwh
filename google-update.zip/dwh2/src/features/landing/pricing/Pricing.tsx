import { useTranslations } from "next-intl";
import { Reveal } from "@/components/Reveal";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { Badge } from "@/components/ui/badge";
import { SECTION_IDS } from "@/constants/sections";
import { DiscountCountdown } from "./components/DiscountCountdown";
import { PricingCard } from "./components/PricingCard";
import { PRICING_PLANS } from "./constants/plans";
import { getDiscountPercent } from "./utils/getDiscountPercent";

/** Two offers, not a SaaS tier ladder — modeled through `PricingPlan` so phase 2's
 * product cards need no rewrite, just a different data source. */
export function Pricing() {
  const t = useTranslations("landing-pricing");
  const featuredPlan = PRICING_PLANS.find((plan) => plan.isFeatured);
  const discountPercent = featuredPlan ? getDiscountPercent(featuredPlan) : null;

  return (
    <Section id={SECTION_IDS.pricing}>
      <SectionHeading
        eyebrow={
          discountPercent != null ? (
            <Badge
              variant="outline"
              className="max-w-full flex-wrap justify-center gap-2 whitespace-normal sm:flex-nowrap sm:whitespace-nowrap"
            >
              {t("eyebrowDiscount", { discountPercent })}
              <span aria-hidden className="opacity-45">
                {"//"}
              </span>
              <DiscountCountdown />
            </Badge>
          ) : undefined
        }
        titleAccent={t("titleAccent")}
        titleRest={t("titleRest")}
        className="mb-12 lg:mb-16"
      />

      <Reveal>
        <div className="mx-auto grid max-w-4xl grid-cols-1 gap-6 pt-3 md:grid-cols-2 md:items-stretch">
          {PRICING_PLANS.map((plan) => (
            <PricingCard key={plan.id} plan={plan} />
          ))}
        </div>
      </Reveal>

      <p className="text-muted-foreground mt-8 text-center text-lg leading-[1.2] font-medium tracking-[-0.03em] text-pretty">
        {t("footnote")}
      </p>
    </Section>
  );
}
