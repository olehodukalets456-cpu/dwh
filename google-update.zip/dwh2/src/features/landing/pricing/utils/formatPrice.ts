/** Puts the currency symbol before the amount and drops trailing zeros in the fraction,
 * regardless of what the locale's default currency formatting would otherwise do. */
export function formatPrice(amount: number, currency: string, locale: string): string {
  const parts = new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    currencyDisplay: "narrowSymbol",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).formatToParts(amount);

  const symbol = parts.find((part) => part.type === "currency")?.value ?? "";
  const number = parts
    .filter((part) => part.type !== "currency" && part.type !== "literal")
    .map((part) => part.value)
    .join("");

  return `${symbol}${number}`;
}