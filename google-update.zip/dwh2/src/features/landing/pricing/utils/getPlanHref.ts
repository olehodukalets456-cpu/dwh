import { PRIMARY_CTA_HREF, SUPPORT_CTA_HREF } from "@/constants/links";
import type { PricingPlan } from "../types";

/** Bot purchase plans and manager-assisted bulk plans intentionally leave through different Telegram links. */
export function getPlanHref(plan: PricingPlan): string {
  if (plan.id === "bulk") return SUPPORT_CTA_HREF;

  return PRIMARY_CTA_HREF;
}
