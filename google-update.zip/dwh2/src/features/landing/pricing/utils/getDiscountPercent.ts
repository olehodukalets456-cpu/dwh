import type { PricingPlan } from "../types";

/** Derived from the real numbers so the badge can never claim a discount the price data doesn't support. */
export function getDiscountPercent({
  priceAmount,
  originalPriceAmount,
}: Pick<PricingPlan, "priceAmount" | "originalPriceAmount">): number | null {
  if (priceAmount == null || !originalPriceAmount) return null;
  return Math.round((1 - priceAmount / originalPriceAmount) * 100);
}
