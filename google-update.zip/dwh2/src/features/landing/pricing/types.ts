/**
 * Shaped like a future product DTO, not like the JSX this section happens to need — phase 2
 * swaps `PRICING_PLANS` for `productService.getProducts()` and `PricingCard` does not change.
 */
export type PricingPlan = {
  /** Stable slug — future product id / catalog route param (`/catalog/${id}`). */
  id: string;
  nameKey: string;
  subTitle: string;
  descriptionKey: string;
  /** A NUMBER, never a pre-formatted "$5" string. `null` means quote-based — contact for a price. */
  priceAmount: number | null;
  /** Pre-discount price for a strikethrough comparison. Ignored when `priceAmount` is null. */
  originalPriceAmount?: number;
  /** ISO 4217. */
  currency: string;
  /** Translated unit shown after the price, e.g. "domain" rendered as "$5 / domain". */
  unitKey?: string;
  featureKeys: readonly string[];
  /** CTA label differs per plan ("Go to the bot" vs "Contact a manager") though the href doesn't — yet. */
  ctaKey: string;
  isFeatured?: boolean;
};
