"use client";

import { useSyncExternalStore } from "react";
import { useTranslations } from "next-intl";

const MS_PER_MINUTE = 60_000;

function getRemainingMs() {
  const now = new Date();
  const midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  return midnight.getTime() - now.getTime();
}

function subscribe(onStoreChange: () => void) {
  const interval = setInterval(onStoreChange, MS_PER_MINUTE);
  return () => clearInterval(interval);
}

const getServerSnapshot = () => null;

/** Counts down to local midnight — "today only" urgency without a fake fixed deadline that
 * would go stale. `useSyncExternalStore` (not an effect + setState) is the correct primitive
 * for a value that changes outside React's render — it also resolves the SSR/client mismatch
 * for free via `getServerSnapshot`. */
export function DiscountCountdown() {
  const t = useTranslations("landing-pricing");
  const remainingMs = useSyncExternalStore(subscribe, getRemainingMs, getServerSnapshot);

  if (remainingMs == null) return null;

  const hours = Math.floor(remainingMs / (MS_PER_MINUTE * 60));
  const minutes = Math.floor((remainingMs % (MS_PER_MINUTE * 60)) / MS_PER_MINUTE);

  return (
    <span>
      {t("countdownLabel")}: {hours} {t("hoursUnit")} {minutes} {t("minutesUnit")}
    </span>
  );
}
