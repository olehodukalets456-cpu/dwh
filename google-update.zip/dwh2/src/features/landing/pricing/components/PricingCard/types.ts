import type { PRICING_PLANS } from "../../constants/plans";

/** Typed from the literal `PRICING_PLANS`, not `PricingPlan`, so `useTranslations` can
 * check `nameKey`/`featureKeys` against the catalog instead of a widened `string`. */
export type PricingCardProps = {
  plan: (typeof PRICING_PLANS)[number];
};
