import { CircleCheck } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { getCtaLinkProps } from "@/constants/links";
import { cn } from "@/lib/utils";
import { formatPrice } from "../../utils/formatPrice";
import { getDiscountPercent } from "../../utils/getDiscountPercent";
import { getPlanHref } from "../../utils/getPlanHref";
import type { PricingCardProps } from "./types";

/**
 * Discount badge sits on a `relative` wrapper outside the `Card`, not inside it — `Card`'s
 * `overflow-hidden` (for image-corner rounding) would clip a badge overlapping the top edge.
 */
export function PricingCard({ plan }: PricingCardProps) {
  const t = useTranslations("landing-pricing");
  const locale = useLocale();
  const discountPercent = getDiscountPercent(plan);

  return (
    <div className="relative h-full">
      {discountPercent ? (
        // Figma export, not a design token — a one-off ribbon gradient/shadow stack has no reusable equivalent.
        <div
          className="absolute -top-3 -right-3 z-10 rotate-6 rounded-full p-0.5 backdrop-blur-[48px] sm:-top-8 sm:-right-12"
          style={{
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            backgroundImage:
              "linear-gradient(90deg, rgba(123, 211, 232, 0.5) 0%, rgba(119, 205, 225, 0.5) 7.14%, rgba(116, 199, 218, 0.5) 14.29%, rgba(112, 193, 212, 0.5) 21.43%, rgba(109, 187, 205, 0.5) 28.57%, rgba(105, 180, 198, 0.5) 35.71%, rgba(101, 175, 192, 0.5) 42.86%, rgba(98, 169, 185, 0.5) 50%, rgba(94, 163, 178, 0.5) 57.14%, rgba(91, 157, 172, 0.5) 64.29%, rgba(88, 151, 165, 0.5) 71.43%, rgba(84, 145, 159, 0.5) 78.57%, rgba(81, 139, 153, 0.5) 85.71%, rgba(77, 134, 146, 0.5) 92.86%, rgba(74, 128, 140, 0.5) 100%)",
            boxShadow:
              "-3px 2px 7px 0px #00000042, -10px 7px 13px 0px #00000038, -23px 17px 17px 0px #00000021, -41px 29px 20px 0px #0000000A, -65px 46px 22px 0px #00000000",
          }}
        >
          <Badge
            variant="outline"
            className="rounded-full border-0 bg-transparent px-3 py-1 text-base sm:px-10 sm:py-5 sm:text-4xl"
            style={{
              backgroundImage:
                "linear-gradient(90deg, rgba(123, 211, 232, 0.2) 0%, rgba(119, 205, 225, 0.2) 7.14%, rgba(116, 199, 218, 0.2) 14.29%, rgba(112, 193, 212, 0.2) 21.43%, rgba(109, 187, 205, 0.2) 28.57%, rgba(105, 180, 198, 0.2) 35.71%, rgba(101, 175, 192, 0.2) 42.86%, rgba(98, 169, 185, 0.2) 50%, rgba(94, 163, 178, 0.2) 57.14%, rgba(91, 157, 172, 0.2) 64.29%, rgba(88, 151, 165, 0.2) 71.43%, rgba(84, 145, 159, 0.2) 78.57%, rgba(81, 139, 153, 0.2) 85.71%, rgba(77, 134, 146, 0.2) 92.86%, rgba(74, 128, 140, 0.2) 100%)",
            }}
          >
            -{discountPercent}%
          </Badge>
        </div>
      ) : null}

      <Card
        className={cn(
          "border-border/60 flex h-full max-w-[490] flex-col p-10 pe-3",
          plan.isFeatured && "border-primary/50 ring-primary/40 shadow-[0_0_40px_-14px_var(--primary)]",
        )}
      >
        <CardHeader className="gap-3">
          <h3 className="text-primary font-mono text-sm leading-[1.2] font-medium tracking-[-0.03em] uppercase">
            {t(plan.nameKey)}
          </h3>

          <p className="text-2xl leading-[1.2] font-medium tracking-[-0.03em] uppercase">{t(plan.subTitle)}</p>

          {plan.priceAmount != null ? (
            <p className="flex flex-wrap items-baseline gap-2">
              {plan.originalPriceAmount ? (
                <span className="text-muted-foreground text-2xl font-medium line-through">
                  {formatPrice(plan.originalPriceAmount, plan.currency, locale)}
                </span>
              ) : null}
              <span className="text-foreground text-4xl font-bold">
                {formatPrice(plan.priceAmount, plan.currency, locale)}
              </span>
              {plan.unitKey ? <span className="text-muted-foreground text-2xl">/ {t(plan.unitKey)}</span> : null}
            </p>
          ) : null}

          <p className="text-muted-foreground text-lg leading-[1.4] font-medium tracking-[-0.03em] text-pretty">
            {t(plan.descriptionKey)}
          </p>
        </CardHeader>

        <CardContent className="flex flex-1 flex-col gap-6 ps-2">
          <ul className="flex flex-col gap-3">
            {plan.featureKeys.map((featureKey) => (
              <li
                key={featureKey}
                className="text-muted-foreground flex items-center gap-2 text-base leading-[1.2] font-medium tracking-[-0.03em]"
              >
                <CircleCheck aria-hidden className="text-primary mt-0.5 size-5 shrink-0" />
                <span>{t(featureKey)}</span>
              </li>
            ))}
          </ul>

          <Button
            asChild
            variant={plan.isFeatured ? "secondary" : "outline"}
            className="mt-auto h-11 w-full rounded-full text-sm font-semibold"
          >
            <a {...getCtaLinkProps(getPlanHref(plan))}>{t(plan.ctaKey)}</a>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
