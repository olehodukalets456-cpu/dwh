import { useTranslations } from "next-intl";
import { Reveal } from "@/components/Reveal";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { Button } from "@/components/ui/button";
import { getCtaLinkProps, isExternalHref, PRIMARY_CTA_HREF, SUPPORT_CTA_HREF } from "@/constants/links";
import { CtaBackdrop } from "./components/CtaBackdrop";
import { CTA_FEATURES } from "./constants";

/** The new-tab hint is only voiced when the destination is actually external. */
export function Cta() {
  const t = useTranslations("landing-cta");
  const primaryOpensExternally = isExternalHref(PRIMARY_CTA_HREF);
  const supportOpensExternally = isExternalHref(SUPPORT_CTA_HREF);

  return (
    <Section className="relative isolate overflow-hidden">
      <CtaBackdrop />

      <SectionHeading
        titleAccent={t("titleAccent")}
        titleRest={t("titleRest")}
        description={t("description")}
        className="mb-12 max-w-6xl lg:mb-16"
      />

      <Reveal className="mx-auto flex max-w-3xl flex-col items-center gap-6 text-center sm:gap-8">
        <ul className="flex flex-wrap items-center justify-center gap-x-6 gap-y-3">
          {CTA_FEATURES.map(({ id, icon: Icon, labelKey }) => (
            <li key={id} className="text-muted-foreground flex items-center gap-2 text-sm">
              <Icon aria-hidden className="text-primary size-4" />
              <span>{t(labelKey)}</span>
            </li>
          ))}
        </ul>

        <div className="flex w-full flex-col items-center justify-center gap-3 sm:w-auto sm:flex-row">
          <Button asChild variant="gradient" className="h-11 w-full px-7 text-sm sm:w-auto">
            <a {...getCtaLinkProps(PRIMARY_CTA_HREF)}>
              {t("primaryCta")}
              {primaryOpensExternally ? <span className="sr-only"> {t("newTabHint")}</span> : null}
            </a>
          </Button>

          <Button asChild variant="outline" className="h-11 w-full rounded-full px-7 text-sm font-semibold sm:w-auto">
            <a {...getCtaLinkProps(SUPPORT_CTA_HREF)}>
              {t("secondaryCta")}
              {supportOpensExternally ? <span className="sr-only"> {t("newTabHint")}</span> : null}
            </a>
          </Button>
        </div>
      </Reveal>
    </Section>
  );
}
