const DOT_PATTERN_ID = "cta-dot-grid";

/**
 * Rendered as SVG + CSS gradients rather than the design's raster watermark, so the section
 * issues no image request. Glow is composed from `--primary` via `color-mix`, no inlined color.
 */
export function CtaBackdrop() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(80%_60%_at_50%_88%,color-mix(in_oklch,var(--primary)_16%,transparent),transparent_70%)]" />

      <span className="text-primary absolute inset-x-0 bottom-0 origin-bottom [transform:perspective(600px)_rotateX(52deg)] text-center font-mono text-[8rem] leading-none font-bold tracking-tighter opacity-[0.05] select-none sm:text-[13rem] lg:text-[17rem]">
        www
      </span>

      <svg
        className="text-primary absolute inset-0 size-full [mask-image:radial-gradient(62%_60%_at_50%_58%,black,transparent)]"
        preserveAspectRatio="none"
      >
        <defs>
          <pattern id={DOT_PATTERN_ID} width="14" height="14" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="1" fill="currentColor" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${DOT_PATTERN_ID})`} opacity="0.32" />
      </svg>
    </div>
  );
}
