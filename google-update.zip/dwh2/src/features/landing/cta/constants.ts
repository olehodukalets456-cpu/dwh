import { SearchCheck, ShieldCheck, Zap } from "lucide-react";
import type { CtaFeature } from "./types";

/**
 * `as const satisfies` keeps the literal `labelKey` types so a key missing from the catalog
 * fails to compile, while still checking the shape against `CtaFeature`.
 */
export const CTA_FEATURES = [
  { id: "vetting", icon: SearchCheck, labelKey: "features.vetting" },
  { id: "history", icon: ShieldCheck, labelKey: "features.history" },
  { id: "instant", icon: Zap, labelKey: "features.instant" },
] as const satisfies readonly CtaFeature[];
