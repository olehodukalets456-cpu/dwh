import type { LucideIcon } from "lucide-react";

export type CtaFeature = {
  id: string;
  icon: LucideIcon;
  labelKey: string;
};
