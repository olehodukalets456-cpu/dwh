import { Advantages } from "./advantages";
import { Compatibility } from "./compatibility";
import { Cta } from "./cta";
import { Faq } from "./faq";
import { Hero } from "./hero";
import { Pricing } from "./pricing";
import { Profit } from "./profit";

/**
 * Section order for the landing. Owned by the foundation, not by the individual sections —
 * each section renders only itself, so parallel work never contends on this file.
 */
export function LandingPage() {
  return (
    <>
      <Hero />
      <Advantages />
      <Compatibility />
      <Profit />
      <Pricing />
      <Faq />
      <Cta />
    </>
  );
}
