import { ArrowLeftRight, MousePointer2 } from "lucide-react";
import Image from "next/image";
import { useTranslations } from "next-intl";
import { Reveal } from "@/components/Reveal";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { Badge } from "@/components/ui/badge";
import { SECTION_IDS } from "@/constants/sections";

/**
 * Credibility section: which traffic sources DWH HUB domains are proven against. Below the
 * fold, so the artwork is wrapped in `Reveal` — nothing here competes with the hero for LCP.
 * The design renders this as one wide dot-matrix render (Google's mark and Meta's mark split
 * by the frame's own centerline), not a two-card logo grid, so it's a single image + one
 * badge rather than a `PlatformCard` per platform.
 */
export function Compatibility() {
  const t = useTranslations("landing-compatibility");
  const tCommon = useTranslations("common");

  return (
    <Section id={SECTION_IDS.compatibility}>
      <SectionHeading
        eyebrow={
          <Badge variant="outline">
            <ArrowLeftRight aria-hidden />
            {t("eyebrow")}
          </Badge>
        }
        titleAccent={t("titleAccent")}
        titleRest={t("titleRest", { brand: tCommon("brand") })}
        className="mb-12 max-w-5xl lg:mb-16"
      />

      <Reveal className="flex flex-col items-center gap-6">
        <div className="relative aspect-1063/553 w-full overflow-hidden">
          <Image
            src="/landing/compatibility/google-meta.png"
            alt={t("logoAlt", { name: "Google, Meta" })}
            fill
            className="object-cover grayscale"
            sizes="(min-width: 1024px) 56rem, 100vw"
          />
          <div
            aria-hidden
            className="absolute top-1/2 left-1/2 h-[130%] w-0.5 -translate-x-1/2 -translate-y-1/2 rotate-15 bg-[linear-gradient(180deg,var(--background)_0%,var(--primary)_50%,var(--background)_100%)]"
          />

          {/* Trigger hit-areas are clipped to the divider's own diagonal so hovering follows the visible split, not a plain vertical half. */}
          <div className="group/google peer/google absolute inset-0 z-10 [clip-path:polygon(0%_0%,56.97%_0%,43.03%_100%,0%_100%)]">
            <div className="absolute inset-y-0 left-0 w-1/2">
              <div className="pointer-events-none absolute top-[60%] right-[-10%] -translate-x-1/2 -translate-y-1/2 opacity-0 transition-opacity duration-300 ease-out group-hover/google:opacity-100">
                <MousePointer2
                  aria-hidden
                  strokeWidth={1.5}
                  className="fill-background/80 text-primary/20 absolute -top-8 -left-8 h-12.5 w-11.75"
                />
                <span className="border-primary/20 bg-background/80 text-primary flex items-center gap-4 rounded-[40px] border-2 px-9 py-6 font-mono text-[32px] leading-[1.2] font-medium tracking-[-0.03em] whitespace-nowrap uppercase backdrop-blur-xl">
                  <Image
                    src="/landing/compatibility/google.svg"
                    alt=""
                    aria-hidden
                    width={32}
                    height={32}
                    className="size-6"
                  />
                  {t("googleBadge")}
                </span>
              </div>
            </div>
          </div>

          <div className="group/meta peer/meta absolute inset-0 z-10 [clip-path:polygon(56.97%_0%,100%_0%,100%_100%,43.03%_100%)]">
            <div className="absolute inset-y-0 right-0 w-1/2">
              <div className="pointer-events-none absolute top-[60%] left-[60%] -translate-x-1/2 -translate-y-1/2 opacity-0 transition-opacity duration-300 ease-out group-hover/meta:opacity-100">
                <MousePointer2
                  aria-hidden
                  strokeWidth={1.5}
                  className="fill-background/80 text-primary/20 absolute -top-8 -left-8 h-12.5 w-11.75"
                />
                <span className="border-primary/20 bg-background/80 text-primary flex items-center gap-4 rounded-[40px] border-2 px-9 py-6 font-mono text-[32px] leading-[1.2] font-medium tracking-[-0.03em] whitespace-nowrap uppercase backdrop-blur-xl">
                  <Image
                    src="/landing/compatibility/meta.svg"
                    alt=""
                    aria-hidden
                    width={32}
                    height={32}
                    className="size-8"
                  />
                  {t("metaBadge")}
                </span>
              </div>
            </div>
          </div>

          {/* Diagonal clips mirror the divider line's own geometry (rotate-15, centered) so each reveal edge aligns exactly. */}
          <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 ease-out [clip-path:polygon(0%_0%,56.97%_0%,43.03%_100%,0%_100%)] peer-hover/google:opacity-100">
            <Image
              src="/landing/compatibility/google-meta.png"
              alt=""
              aria-hidden
              fill
              className="object-cover"
              sizes="(min-width: 1024px) 56rem, 100vw"
            />
          </div>
          <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 ease-out [clip-path:polygon(56.97%_0%,100%_0%,100%_100%,43.03%_100%)] peer-hover/meta:opacity-100">
            <Image
              src="/landing/compatibility/google-meta.png"
              alt=""
              aria-hidden
              fill
              className="object-cover"
              sizes="(min-width: 1024px) 56rem, 100vw"
            />
          </div>
        </div>

        <p className="text-muted-foreground max-w-[400] text-center text-lg leading-[1.2] font-medium tracking-[-0.03em] text-pretty">
          {t("description")}
        </p>
      </Reveal>
    </Section>
  );
}
