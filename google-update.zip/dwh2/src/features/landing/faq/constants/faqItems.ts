import type { FaqItem } from "../types";

/**
 * `as const satisfies` keeps literal `questionKey`/`answerKey` types so a missing catalog key
 * fails to compile. Order here is both the render order and the JSON-LD order.
 */
export const FAQ_ITEMS = [
  {
    id: "what-is-aged-domain",
    questionKey: "items.whatIsAgedDomain.question",
    answerKey: "items.whatIsAgedDomain.answer",
  },
  {
    id: "clean-history",
    questionKey: "items.cleanHistory.question",
    answerKey: "items.cleanHistory.answer",
  },
  {
    id: "domain-verification",
    questionKey: "items.domainVerification.question",
    answerKey: "items.domainVerification.answer",
  },
  {
    id: "verification-history",
    questionKey: "items.verificationHistory.question",
    answerKey: "items.verificationHistory.answer",
  },
  {
    id: "how-to-buy",
    questionKey: "items.howToBuy.question",
    answerKey: "items.howToBuy.answer",
  },
  {
    id: "delivery-time",
    questionKey: "items.deliveryTime.question",
    answerKey: "items.deliveryTime.answer",
  },
  {
    id: "dns-setup",
    questionKey: "items.dnsSetup.question",
    answerKey: "items.dnsSetup.answer",
  },
  {
    id: "renewal-timeline",
    questionKey: "items.renewalTimeline.question",
    answerKey: "items.renewalTimeline.answer",
  },
  {
    id: "better-than-newregs",
    questionKey: "items.betterThanNewregs.question",
    answerKey: "items.betterThanNewregs.answer",
  },
  {
    id: "ready-without-warmup",
    questionKey: "items.readyWithoutWarmup.question",
    answerKey: "items.readyWithoutWarmup.answer",
  },
] as const satisfies readonly FaqItem[];

/** Deep-link anchor id shared by the accordion item's DOM id and the JSON-LD `Question` `@id`. */
export const faqAnchorId = (id: string) => `faq-${id}` as const;
