import { serializeJsonLd } from "@/lib/jsonLd";
import { faqAnchorId } from "../constants/faqItems";

/** A FAQ entry after its keys have been resolved to the active locale's copy. */
export type ResolvedFaqItem = {
  id: string;
  question: string;
  answer: string;
};

/**
 * Built from the SAME resolved copy the accordion renders, so the structured data can
 * never describe text the page does not show.
 */
export function buildFaqJsonLd(items: readonly ResolvedFaqItem[]): string {
  const data = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((item) => ({
      "@type": "Question",
      "@id": `#${faqAnchorId(item.id)}`,
      name: item.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: item.answer,
      },
    })),
  };

  return serializeJsonLd(data);
}
