export { FaqAccordion } from "./FaqAccordion";
