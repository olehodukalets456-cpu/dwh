"use client";

import { useTranslations } from "next-intl";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { FAQ_ITEMS, faqAnchorId } from "../../constants/faqItems";

/**
 * Radix drives the ARIA and keyboard behaviour; `type="single"` matches the design
 * (one answer open at a time, first item expanded by default).
 */
export function FaqAccordion() {
  const t = useTranslations("landing-faq");

  return (
    <Accordion
      type="single"
      collapsible
      defaultValue={FAQ_ITEMS[0].id}
      className="border-border bg-card/60 overflow-hidden rounded-2xl border"
    >
      {FAQ_ITEMS.map((item) => (
        <AccordionItem key={item.id} id={faqAnchorId(item.id)} value={item.id} className="scroll-mt-24 px-5 sm:px-6">
          <AccordionTrigger className="py-4 text-base font-medium sm:py-5">{t(item.questionKey)}</AccordionTrigger>
          <AccordionContent className="text-muted-foreground text-sm leading-relaxed text-pretty whitespace-pre-line">
            {t(item.answerKey)}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
