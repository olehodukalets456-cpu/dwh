/** `id` seeds both the deep-link anchor (`faq-<id>`) and the JSON-LD `Question` `@id`, so
 * the accordion item and structured data can never drift apart. */
export type FaqItem = {
  id: string;
  questionKey: string;
  answerKey: string;
};
