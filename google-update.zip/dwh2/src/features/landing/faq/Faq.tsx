import { CircleHelp } from "lucide-react";
import { useTranslations } from "next-intl";
import { Reveal } from "@/components/Reveal";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getCtaLinkProps, SUPPORT_CTA_HREF } from "@/constants/links";
import { SECTION_IDS } from "@/constants/sections";
import { FaqAccordion } from "./components/FaqAccordion";
import { FAQ_ITEMS } from "./constants/faqItems";
import { buildFaqJsonLd } from "./utils/faqJsonLd";

/** The visible accordion and the JSON-LD are both driven by `FAQ_ITEMS`, so the markup
 * Google reads always matches the text a visitor sees. */
export function Faq() {
  const t = useTranslations("landing-faq");

  const jsonLd = buildFaqJsonLd(
    FAQ_ITEMS.map((item) => ({ id: item.id, question: t(item.questionKey), answer: t(item.answerKey) })),
  );

  return (
    <Section id={SECTION_IDS.faq}>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd }} />

      <SectionHeading
        eyebrow={
          <Badge variant="outline">
            <CircleHelp aria-hidden />
            {t("eyebrow")}
          </Badge>
        }
        titleAccent={t("titleAccent")}
        titleRest={t("titleRest")}
        className="mb-12 lg:mb-16"
      />

      <Reveal className="mx-auto flex w-full max-w-3xl flex-col items-center gap-8">
        <FaqAccordion />

        <div className="flex flex-col items-center gap-3">
          <p className="text-muted-foreground text-lg leading-[1.2] font-medium tracking-[-0.03em]">{t("still")}</p>
          <Button asChild variant="secondary" className="h-11 rounded-full px-5 py-3.5">
            <a {...getCtaLinkProps(SUPPORT_CTA_HREF)}>{t("askManager")}</a>
          </Button>
        </div>
      </Reveal>
    </Section>
  );
}
