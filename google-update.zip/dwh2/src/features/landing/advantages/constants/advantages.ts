import type { Advantage } from "../types";

/** `as const satisfies` keeps literal `titleKey`/`descriptionKey` types so a missing
 * catalog key fails to compile instead of a runtime `MISSING_MESSAGE`. Icons are the
 * Figma-exported glyphs, in the same order as the design's grid. */
export const ADVANTAGES = [
  {
    id: "clean-history",
    iconSrc: "/landing/advantages/shield-check.svg",
    titleKey: "items.cleanHistory.title",
    descriptionKey: "items.cleanHistory.description",
  },
  {
    id: "ad-loyalty",
    iconSrc: "/landing/advantages/heart.svg",
    titleKey: "items.adLoyalty.title",
    descriptionKey: "items.adLoyalty.description",
  },
  {
    id: "instant-flow",
    iconSrc: "/landing/advantages/zap.svg",
    titleKey: "items.instantFlow.title",
    descriptionKey: "items.instantFlow.description",
  },
  {
    id: "fewer-bans",
    iconSrc: "/landing/advantages/ban.svg",
    titleKey: "items.fewerBans.title",
    descriptionKey: "items.fewerBans.description",
  },
  {
    id: "lower-cpl",
    iconSrc: "/landing/advantages/trending-up.svg",
    titleKey: "items.lowerCpl.title",
    descriptionKey: "items.lowerCpl.description",
  },
  {
    id: "instant-bulk",
    iconSrc: "/landing/advantages/square.svg",
    titleKey: "items.instantBulk.title",
    descriptionKey: "items.instantBulk.description",
  },
] as const satisfies readonly Advantage[];
