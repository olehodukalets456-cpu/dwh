import type { ReactNode } from "react";

export type AdvantageCardProps = {
  id: string;
  iconSrc: string;
  title: ReactNode;
  description: ReactNode;
};
