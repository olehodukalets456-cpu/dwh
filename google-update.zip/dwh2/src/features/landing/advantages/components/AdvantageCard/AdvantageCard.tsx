import Image from "next/image";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import type { AdvantageCardProps } from "./types";

const DOT_PATTERN_ID_PREFIX = "advantage-dot-grid";

/**
 * shadcn's `CardTitle` renders a `div`, so the heading is written by hand here to keep the
 * section's `h2` → `h3` outline intact. Each card gets its own dot-grid + oversized icon
 * watermark, faded in on hover/focus — built from the card's own icon (not a shared raster),
 * so all six read as distinct rather than reusing one background image six times.
 */
export function AdvantageCard({ id, iconSrc, title, description }: AdvantageCardProps) {
  const patternId = `${DOT_PATTERN_ID_PREFIX}-${id}`;

  return (
    <Card className="group border-border/60 relative h-full overflow-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 ease-out group-focus-within:opacity-100 group-hover:opacity-100"
      >
        <svg className="text-primary absolute inset-0 size-full" preserveAspectRatio="none">
          <defs>
            <pattern id={patternId} width="10" height="10" patternUnits="userSpaceOnUse">
              <circle cx="1" cy="1" r="1" fill="currentColor" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill={`url(#${patternId})`} opacity="0.5" />
        </svg>
        <Image
          src={iconSrc}
          alt=""
          width={96}
          height={96}
          aria-hidden
          className="text-primary absolute top-8 right-4 size-24 opacity-20"
        />
        <div className="from-card absolute inset-0 bg-gradient-to-t via-transparent to-transparent" />
      </div>

      <CardHeader className="relative">
        <span className="bg-primary/10 text-primary mb-2 inline-flex size-10 items-center justify-center rounded-full">
          <Image src={iconSrc} alt="" aria-hidden width={20} height={20} className="size-5" />
        </span>
        <h3 className="font-heading text-base leading-snug font-medium tracking-[-0.03em]">{title}</h3>
      </CardHeader>
      <CardContent className="relative">
        <p className="text-muted-foreground text-base text-pretty">{description}</p>
      </CardContent>
    </Card>
  );
}
