import { Star } from "lucide-react";
import { useTranslations } from "next-intl";
import { Reveal } from "@/components/Reveal";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { Badge } from "@/components/ui/badge";
import { SECTION_IDS } from "@/constants/sections";
import { AdvantageCard } from "./components/AdvantageCard";
import { ADVANTAGES } from "./constants/advantages";

/** Why an aged DWH HUB domain outperforms a fresh/self-farmed one — the case made in six data-driven cards. */
export function Advantages() {
  const t = useTranslations("landing-advantages");

  return (
    <Section id={SECTION_IDS.advantages}>
      <SectionHeading
        eyebrow={
          <Badge variant="outline">
            <Star aria-hidden />
            {t("eyebrow")}
          </Badge>
        }
        titleAccent={t("titleAccent")}
        titleRest={t("titleRest")}
        className="mb-12 lg:mb-16"
      />

      <Reveal>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {ADVANTAGES.map(({ id, iconSrc, titleKey, descriptionKey }) => (
            <AdvantageCard key={id} id={id} iconSrc={iconSrc} title={t(titleKey)} description={t(descriptionKey)} />
          ))}
        </div>
      </Reveal>
    </Section>
  );
}
