/**
 * One reason card. `titleKey`/`descriptionKey` resolve against the `landing-advantages`
 * namespace — swapping this constant for a CMS/API response later needs no component change.
 * `iconSrc` is the exported Figma glyph, reused twice: small in the badge, large as the
 * hover-reveal watermark — so the two never drift out of sync.
 */
export type Advantage = {
  id: string;
  iconSrc: string;
  titleKey: string;
  descriptionKey: string;
};
