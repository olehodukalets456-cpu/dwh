import { Handshake, SearchCheck, ShieldCheck, TrendingUp, Zap } from "lucide-react";
import type { TrustSignal } from "./types";

/**
 * `as const satisfies` rather than a plain annotation: the shape is still checked, but the
 * literal `labelKey` types survive, so a key that is missing from the catalog fails to compile.
 */
export const TRUST_SIGNALS = [
  { id: "loyalty", icon: Handshake, labelKey: "signals.loyalty" },
  { id: "transparency", icon: SearchCheck, labelKey: "signals.transparency" },
  { id: "roi", icon: TrendingUp, labelKey: "signals.roi" },
  { id: "reputation", icon: ShieldCheck, labelKey: "signals.reputation" },
  { id: "instant", icon: Zap, labelKey: "signals.instant" },
] as const satisfies readonly TrustSignal[];
