import { Search } from "lucide-react";
import { useTranslations } from "next-intl";
import { buttonVariants } from "@/components/ui/button";
import { getCtaLinkProps } from "@/constants/links";
import { cn } from "@/lib/utils";

/** The whole pill is one anchor, not a text input — there is nothing to search yet, and a
 * real input would fake a control that does nothing. */
export function HeroSearchCta() {
  const t = useTranslations("landing-hero");

  return (
    <a
      {...getCtaLinkProps()}
      className="group border-border bg-card/70 ring-ring/50 hover:border-primary/40 flex w-full max-w-xl items-center gap-3 rounded-full border p-1.5 pl-5 shadow-lg backdrop-blur transition-colors focus-visible:ring-3 focus-visible:outline-none"
    >
      <Search aria-hidden className="text-muted-foreground size-4" />

      <span aria-hidden className="text-muted-foreground min-w-0 flex-1 truncate text-left font-mono text-sm">
        {t("searchExample")}
      </span>

      <span
        className={cn(
          buttonVariants({ variant: "silver" }),
          "h-11 shrink-0 px-5 whitespace-nowrap",
        )}
      >
        {t("cta")}
      </span>
    </a>
  );
}
