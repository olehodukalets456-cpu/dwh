const DOT_PATTERN_ID = "hero-dot-grid";

/** Wave arcs radiating from a focal point below the headline, largest last. */
const ARCS = [
  { rx: "34%", ry: "48%" },
  { rx: "50%", ry: "66%" },
  { rx: "68%", ry: "86%" },
  { rx: "88%", ry: "108%" },
] as const;

/**
 * Decorative dot-grid wave behind the first screen. Rendered as SVG + CSS gradients instead of
 * the design's raster: the LCP screen issues no image request and has no dimensions to shift.
 */
export function HeroBackdrop() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(70%_55%_at_50%_42%,color-mix(in_oklch,var(--primary)_14%,transparent),transparent_72%)]" />

      <svg
        className="text-primary absolute inset-0 size-full [mask-image:radial-gradient(62%_58%_at_50%_45%,black,transparent)]"
        preserveAspectRatio="none"
      >
        <defs>
          <pattern id={DOT_PATTERN_ID} width="14" height="14" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="1" fill="currentColor" />
          </pattern>
        </defs>

        <rect width="100%" height="100%" fill={`url(#${DOT_PATTERN_ID})`} opacity="0.4" />

        <g fill="none" stroke="currentColor" strokeOpacity="0.22" strokeWidth="1">
          {ARCS.map(({ rx, ry }) => (
            <ellipse key={rx} cx="50%" cy="112%" rx={rx} ry={ry} />
          ))}
        </g>
      </svg>

      <div className="to-background absolute inset-x-0 bottom-0 h-32 bg-gradient-to-b from-transparent" />
    </div>
  );
}
