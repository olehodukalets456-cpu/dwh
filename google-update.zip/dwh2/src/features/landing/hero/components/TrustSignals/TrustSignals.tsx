import { useTranslations } from "next-intl";
import { TRUST_SIGNALS } from "../../constants";

/** Scrolls horizontally in its own container rather than wrapping, so the page body never
 * scrolls sideways. `tabIndex` makes the region keyboard-reachable since its pills aren't focusable. */
export function TrustSignals() {
  const t = useTranslations("landing-hero");

  return (
    <ul
      tabIndex={0}
      className="ring-ring/50 flex w-full [scrollbar-width:none] gap-2 overflow-x-auto rounded-full [mask-image:linear-gradient(to_right,transparent,black_6%,black_94%,transparent)] focus-visible:ring-3 focus-visible:outline-none [&::-webkit-scrollbar]:hidden"
    >
      {TRUST_SIGNALS.map(({ id, icon: Icon, labelKey }) => (
        <li
          key={id}
          className="border-border bg-card/60 text-muted-foreground group flex shrink-0 items-center gap-2 rounded-full border px-4 py-2 backdrop-blur"
        >
          <Icon aria-hidden className="text-primary size-3.5" />
          <span className="group-hover:text-primary text-center font-mono text-sm leading-[1.2] font-medium tracking-[-0.03em] whitespace-nowrap transition-colors [text-box-edge:cap_alphabetic] [text-box-trim:trim-both]">
            {t(labelKey)}
          </span>
        </li>
      ))}
    </ul>
  );
}
