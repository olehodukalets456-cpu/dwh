import { useTranslations } from "next-intl";
import { Section } from "@/components/Section";
import { HeroBackdrop } from "./components/HeroBackdrop";
import { HeroSearchCta } from "./components/HeroSearchCta";
import { TrustSignals } from "./components/TrustSignals";

/** The page's LCP element — composes the headline locally (no `SectionHeading`, no
 * scroll-reveal) so nothing here waits on JavaScript to paint. */
export function Hero() {
  const t = useTranslations("landing-hero");

  return (
    <Section className="relative isolate overflow-hidden pt-12 pb-16 sm:pt-16 sm:pb-20 lg:pt-24 lg:pb-24">
      <HeroBackdrop />

      <div className="flex flex-col items-center gap-6 text-center sm:gap-8">
        <h1 className="max-w-4xl text-3xl font-semibold tracking-[-0.05em] text-balance uppercase sm:text-5xl lg:text-6xl">
          <span className="text-primary block">{t("titleAccent")}</span>
          <span className="block">{t("titleRest")}</span>
        </h1>

        <p className="text-muted-foreground max-w-xl font-mono text-lg leading-[1.2] font-medium tracking-[-0.03em] text-pretty uppercase">
          {t("subtitle")}
        </p>

        <HeroSearchCta />
        <TrustSignals />
      </div>
    </Section>
  );
}
