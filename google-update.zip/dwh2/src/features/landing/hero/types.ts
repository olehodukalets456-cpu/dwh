import type { LucideIcon } from "lucide-react";

/**
 * One proof-point pill under the hero CTA. `labelKey` resolves against the `landing-hero`
 * namespace, so the copy is translatable and editable without touching this module.
 */
export type TrustSignal = {
  id: string;
  icon: LucideIcon;
  labelKey: string;
};
