import { DollarSign } from "lucide-react";
import { useTranslations } from "next-intl";
import { Reveal } from "@/components/Reveal";
import { Section } from "@/components/Section";
import { SectionHeading } from "@/components/SectionHeading";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getCtaLinkProps } from "@/constants/links";
import { SECTION_IDS } from "@/constants/sections";
import Image from "next/image";

/**
 * The persuasion peak of the page: real campaign economics, not a claim — a random domain
 * loses to a DWH HUB domain with history on every metric, side by side.
 */
export function Profit() {
  const t = useTranslations("landing-profit");

  return (
    <Section id={SECTION_IDS.profit}>
      <SectionHeading
        eyebrow={
          <Badge variant="outline">
            <DollarSign aria-hidden />
            {t("eyebrow")}
          </Badge>
        }
        titleAccent={t("titleAccent")}
        titleRest={t("titleRest")}
        description={t("description")}
        className="mb-12 lg:mb-16"
      />

      <Reveal className="flex flex-col items-center gap-8">
        <div className="mx-auto flex w-full max-w-4xl flex-col gap-4">
          <div className="relative mx-auto w-[92.34%]">
            <Image
              src="/landing/profit/table_1.svg"
              alt={t("logoAlt", { name: "Random domain" })}
              width={1000}
              height={100}
              className="h-auto w-full"
              sizes="(min-width: 1024px) 56rem, 100vw"
            />
            <Image
              src="/landing/profit/cross.svg"
              alt=""
              aria-hidden
              width={55}
              height={55}
              className="absolute -top-2 -right-2 size-6 sm:-top-4 sm:-right-4 sm:size-8 lg:-top-6 lg:-right-6 lg:size-11"
            />
          </div>

          <div className="relative w-full">
            <Image
              src="/landing/profit/table_2.svg"
              alt={t("logoAlt", { name: "DWH domain" })}
              width={1083}
              height={183}
              className="h-auto w-full"
              sizes="(min-width: 1024px) 56rem, 100vw"
            />
            <Image
              src="/landing/profit/check.svg"
              alt=""
              aria-hidden
              width={60}
              height={60}
              className="absolute top-0.5 size-8 sm:top-1 sm:size-10 lg:top-2 lg:size-16"
            />
          </div>

          <p className="text-muted-foreground text-center text-xs text-pretty">{t("tableCaption")}</p>
        </div>

        <Button asChild variant="secondary" className="h-11 px-7">
          <a {...getCtaLinkProps()}>{t("cta")}</a>
        </Button>
      </Reveal>
    </Section>
  );
}
