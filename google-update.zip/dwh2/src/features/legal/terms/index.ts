export { TermsPage } from "./TermsPage";
