import { getTranslations } from "next-intl/server";
import { Section } from "@/components/Section";

type ProhibitedItem = { title: string; description: string };

const HEADING_CLASS = "text-xl leading-[1.2] font-semibold tracking-[-0.03em]";
const PARAGRAPH_CLASS = "text-muted-foreground text-base leading-relaxed text-pretty";

/** Legal copy has no per-locale structural differences, so sections are hand-written here
 * rather than looped from a generic key list next-intl's typed `t()` can't index dynamically. */
export async function TermsPage() {
  const t = await getTranslations("legal-terms");
  const prohibitedItems = t.raw("sections.prohibited.items") as ProhibitedItem[];

  return (
    <Section containerClassName="max-w-3xl">
      <h1 className="text-3xl leading-[1.2] font-semibold tracking-[-0.03em] text-balance sm:text-4xl">
        {t("title")}
      </h1>
      <p className="text-muted-foreground mt-3 text-sm">
        {t("lastUpdatedLabel")} {t("lastUpdatedDate")}
      </p>
      <p className={`mt-8 ${PARAGRAPH_CLASS}`}>{t("intro")}</p>

      <div className="mt-12 flex flex-col gap-10">
        <section className="flex flex-col gap-3">
          <h2 className={HEADING_CLASS}>{t("sections.services.heading")}</h2>
          {(t.raw("sections.services.paragraphs") as string[]).map((paragraph) => (
            <p key={paragraph} className={PARAGRAPH_CLASS}>
              {paragraph}
            </p>
          ))}
        </section>

        <section className="flex flex-col gap-3">
          <h2 className={HEADING_CLASS}>{t("sections.account.heading")}</h2>
          {(t.raw("sections.account.paragraphs") as string[]).map((paragraph) => (
            <p key={paragraph} className={PARAGRAPH_CLASS}>
              {paragraph}
            </p>
          ))}
        </section>

        <section className="flex flex-col gap-4">
          <h2 className={HEADING_CLASS}>{t("sections.prohibited.heading")}</h2>
          <p className={PARAGRAPH_CLASS}>{t("sections.prohibited.intro")}</p>
          <p className="text-foreground text-base font-medium">{t("sections.prohibited.listIntro")}</p>
          <ul className="flex flex-col gap-3">
            {prohibitedItems.map((item) => (
              <li key={item.title} className={PARAGRAPH_CLASS}>
                <span className="text-foreground font-medium">{item.title}: </span>
                {item.description}
              </li>
            ))}
          </ul>
        </section>

        <section id="refund" className="scroll-mt-20 flex flex-col gap-3">
          <h2 className={HEADING_CLASS}>{t("sections.refund.heading")}</h2>
          {(t.raw("sections.refund.paragraphs") as string[]).map((paragraph) => (
            <p key={paragraph} className={PARAGRAPH_CLASS}>
              {paragraph}
            </p>
          ))}
        </section>

        <section className="flex flex-col gap-3">
          <h2 className={HEADING_CLASS}>{t("sections.liability.heading")}</h2>
          {(t.raw("sections.liability.paragraphs") as string[]).map((paragraph) => (
            <p key={paragraph} className={PARAGRAPH_CLASS}>
              {paragraph}
            </p>
          ))}
        </section>

        <section className="flex flex-col gap-3">
          <h2 className={HEADING_CLASS}>{t("sections.changes.heading")}</h2>
          {(t.raw("sections.changes.paragraphs") as string[]).map((paragraph) => (
            <p key={paragraph} className={PARAGRAPH_CLASS}>
              {paragraph}
            </p>
          ))}
        </section>
      </div>
    </Section>
  );
}
