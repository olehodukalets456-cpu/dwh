const TELEGRAM_BOT_HREF =
  "https://t.me/domains_with_history_bot?start=src_75c0f7b4-06a1-4bfd-b864-2433787f52ad";
const TELEGRAM_SUPPORT_HREF = "https://t.me/Domains_shop_support";

/** Every outbound Telegram destination in one place. */
export const EXTERNAL_LINKS = {
  telegramBot: TELEGRAM_BOT_HREF,
  telegramChannel: TELEGRAM_BOT_HREF,
  support: TELEGRAM_SUPPORT_HREF,
} as const;

export const PRIMARY_CTA_HREF = EXTERNAL_LINKS.telegramBot;
export const SUPPORT_CTA_HREF = EXTERNAL_LINKS.support;

export const isExternalHref = (href: string) => /^https?:\/\//.test(href);

/**
 * Anchor props for a CTA whose destination may be internal or external.
 * Spread onto an `<a>`; external targets get the `noopener noreferrer` guard automatically.
 */
export function getCtaLinkProps(href: string = PRIMARY_CTA_HREF) {
  return isExternalHref(href) ? ({ href, target: "_blank", rel: "noopener noreferrer" } as const) : ({ href } as const);
}
