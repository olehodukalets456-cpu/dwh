/** Single source of truth shared by section components (DOM id) and navigation (link href),
 * so neither side can drift from the other. */
export const SECTION_IDS = {
  advantages: "advantages",
  compatibility: "compatibility",
  profit: "profit",
  pricing: "pricing",
  faq: "faq",
} as const;

export type SectionId = (typeof SECTION_IDS)[keyof typeof SECTION_IDS];

export const sectionHref = (id: SectionId) => `#${id}` as const;
