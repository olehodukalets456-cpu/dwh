/** Standard API envelope — services unwrap `.data` and return the domain payload. */
export interface ApiResponse<T, M = unknown> {
  data: T;
  meta: M;
}

export interface IdName<T = string | number> {
  id: T;
  name: string;
}

export interface SelectOption {
  key: string | number;
  label: string;
  [k: string]: unknown;
}
