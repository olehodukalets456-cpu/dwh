/**
 * Wired into next-intl's `AppConfig` so `t("…")` autocompletes and an unknown key fails to
 * compile. `en` is the source of truth; keep in sync with `NAMESPACES` in `src/i18n/request.ts`.
 */
type Messages = {
  common: typeof import("../../messages/en/common.json");
  navigation: typeof import("../../messages/en/navigation.json");
  footer: typeof import("../../messages/en/footer.json");
  "landing-hero": typeof import("../../messages/en/landing-hero.json");
  "landing-advantages": typeof import("../../messages/en/landing-advantages.json");
  "landing-compatibility": typeof import("../../messages/en/landing-compatibility.json");
  "landing-profit": typeof import("../../messages/en/landing-profit.json");
  "landing-pricing": typeof import("../../messages/en/landing-pricing.json");
  "landing-faq": typeof import("../../messages/en/landing-faq.json");
  "landing-cta": typeof import("../../messages/en/landing-cta.json");
  "legal-terms": typeof import("../../messages/en/legal-terms.json");
  "free-domain-popup": typeof import("../../messages/en/free-domain-popup.json");
};

// Marks this file as a module, so the block below *augments* next-intl rather than
// declaring an ambient module that shadows it.
export {};

declare module "next-intl" {
  interface AppConfig {
    Messages: Messages;
  }
}
