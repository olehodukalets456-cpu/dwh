"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { getCtaLinkProps, SUPPORT_CTA_HREF } from "@/constants/links";

const SHOWN_KEY = "dwh-free-domain-popup-shown";
const DELAY_MS = 30_000;

/** Session-scoped, not persisted — a returning visitor in a new tab sees the offer again,
 * but it won't re-interrupt the same session after being shown or dismissed once. */
export function FreeDomainPopup() {
  const t = useTranslations("free-domain-popup");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem(SHOWN_KEY)) return;

    const timer = setTimeout(() => {
      sessionStorage.setItem(SHOWN_KEY, "1");
      setOpen(true);
    }, DELAY_MS);

    return () => clearTimeout(timer);
  }, []);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg">{t("title")}</DialogTitle>
          <DialogDescription>{t("subtitle")}</DialogDescription>
        </DialogHeader>

        <Button asChild variant="gradient" className="w-full">
          <a {...getCtaLinkProps(SUPPORT_CTA_HREF)} onClick={() => setOpen(false)}>
            {t("cta")}
          </a>
        </Button>
      </DialogContent>
    </Dialog>
  );
}
