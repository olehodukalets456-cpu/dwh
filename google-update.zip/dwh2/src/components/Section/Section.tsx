import { cn } from "@/lib/utils";
import type { SectionProps } from "./types";

/** `scroll-mt-20` clears the sticky 4rem header when an anchor link jumps here — keep it
 * above the header height if the header ever grows. */
export function Section({ children, id, className, containerClassName }: SectionProps) {
  return (
    <section id={id} className={cn("scroll-mt-20 py-16 sm:py-20 lg:py-28", className)}>
      <div className={cn("mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8", containerClassName)}>{children}</div>
    </section>
  );
}
