import type { ReactNode } from "react";
import type { SectionId } from "@/constants/sections";

export type SectionProps = {
  children: ReactNode;
  /** Anchor target. Omit for sections the navigation does not link to (hero, closing CTA). */
  id?: SectionId;
  /** Classes for the outer `<section>` — backgrounds, borders, vertical padding overrides. */
  className?: string;
  /** Classes for the inner container — width or layout overrides. */
  containerClassName?: string;
};
