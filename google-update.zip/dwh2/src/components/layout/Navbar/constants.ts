import { SECTION_IDS, sectionHref } from "@/constants/sections";

/**
 * Header anchors. The design surfaces only three of the five anchorable sections — the header
 * is a conversion path, not a table of contents. `labelKey` resolves against `navigation`.
 */
export const NAV_LINKS = [
  { href: sectionHref(SECTION_IDS.advantages), labelKey: "whyUs" },
  { href: sectionHref(SECTION_IDS.pricing), labelKey: "pricing" },
  { href: sectionHref(SECTION_IDS.faq), labelKey: "faq" },
] as const;
