import { useTranslations } from "next-intl";

const TRACK_REPEATS = 8;

/** Two identical tracks translate by -50% (exactly one track's width) for a seamless loop.
 * The marquee is `aria-hidden`; the message is exposed once via `sr-only` instead. */
export function PromoBar() {
  const t = useTranslations("navigation");
  const message = t("promo");

  return (
    <div className="bg-primary relative overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)] py-2">
      <span className="sr-only">{message}</span>

      <div aria-hidden className="animate-marquee flex w-max motion-reduce:animate-none">
        {[0, 1].map((track) => (
          <div key={track} className="flex shrink-0 items-center">
            {Array.from({ length: TRACK_REPEATS }).map((_, index) => (
              <span
                key={index}
                className="text-primary-foreground font-mono text-[11px] font-medium tracking-[0.16em] whitespace-nowrap uppercase"
              >
                {message}
                <span className="px-3 opacity-45">{"//"}</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
