export type ActiveSectionNavProps = {
  className?: string;
};
