"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { cn } from "@/lib/utils";
import { NAV_LINKS } from "../../constants";
import type { ActiveSectionNavProps } from "./types";

/** Initial render has no active link (matches SSR output); the observer only starts
 * after mount, so there is nothing for hydration to mismatch against. */
export function ActiveSectionNav({ className }: ActiveSectionNavProps) {
  const t = useTranslations("navigation");
  const [activeHref, setActiveHref] = useState<string | null>(null);

  useEffect(() => {
    const sections = NAV_LINKS.map(({ href }) => document.getElementById(href.slice(1))).filter(
      (el): el is HTMLElement => el !== null,
    );

    if (sections.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting);
        if (visible.length === 0) return;
        const topMost = visible.reduce((a, b) => (a.boundingClientRect.top < b.boundingClientRect.top ? a : b));
        setActiveHref(`#${topMost.target.id}`);
      },
      { rootMargin: "-96px 0px -60% 0px", threshold: 0 },
    );

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  return (
    <nav className={className} aria-label={t("menuTitle")}>
      {NAV_LINKS.map(({ href, labelKey }) => {
        const isActive = activeHref === href;
        return (
          <a
            key={href}
            href={href}
            aria-current={isActive ? "location" : undefined}
            className={cn(
              "relative font-mono text-xs font-medium tracking-[0.14em] whitespace-nowrap uppercase transition-colors",
              isActive ? "text-primary" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {isActive && (
              <span
                aria-hidden
                className="bg-primary absolute top-1/2 -left-3.5 size-1.5 -translate-y-1/2 rounded-full"
              />
            )}
            {t(labelKey)}
          </a>
        );
      })}
    </nav>
  );
}
