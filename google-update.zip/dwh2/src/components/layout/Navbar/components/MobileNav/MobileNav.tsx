"use client";

import { MenuIcon, SendIcon } from "lucide-react";
import { useTranslations } from "next-intl";
import { useState } from "react";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { getCtaLinkProps, PRIMARY_CTA_HREF } from "@/constants/links";
import { NAV_LINKS } from "../../constants";

export function MobileNav() {
  const t = useTranslations("navigation");
  const [open, setOpen] = useState(false);
  const ctaLinkProps = getCtaLinkProps(PRIMARY_CTA_HREF);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" aria-label={t("openMenu")} className="lg:hidden">
          <MenuIcon className="size-5" />
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle className="sr-only">{t("menuTitle")}</SheetTitle>
          <SheetDescription className="sr-only">{t("menuTitle")}</SheetDescription>
        </SheetHeader>

        <div className="flex items-center px-4">
          <LanguageSwitcher />
        </div>
        <Separator />

        <nav aria-label={t("menuTitle")} className="flex flex-col gap-1 px-4">
          {NAV_LINKS.map(({ href, labelKey }) => (
            <SheetClose asChild key={href}>
              <a
                href={href}
                className="text-foreground hover:bg-muted rounded-md px-3 py-3 text-xs font-medium tracking-[0.14em] uppercase transition-colors"
              >
                {t(labelKey)}
              </a>
            </SheetClose>
          ))}
        </nav>

        <SheetFooter>
          <SheetClose asChild>
            <Button asChild variant="gradient" className="h-11">
              <a {...ctaLinkProps}>
                <SendIcon className="size-4" />
                {t("openBot")}
              </a>
            </Button>
          </SheetClose>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
