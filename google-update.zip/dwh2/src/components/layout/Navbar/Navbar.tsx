import { SendIcon } from "lucide-react";
import { useTranslations } from "next-intl";
import { BrandMark } from "@/components/BrandMark";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { Button } from "@/components/ui/button";
import { getCtaLinkProps, PRIMARY_CTA_HREF } from "@/constants/links";
import { Link } from "@/i18n/navigation";
import { ActiveSectionNav } from "./components/ActiveSectionNav";
import { MobileNav } from "./components/MobileNav";
import { PromoBar } from "./components/PromoBar";

/** `PromoBar` sits below the header and is deliberately not sticky, so the pinned area
 * stays one row instead of the ticker permanently eating viewport height. */
export function Navbar() {
  const t = useTranslations("navigation");
  const ctaLinkProps = getCtaLinkProps(PRIMARY_CTA_HREF);

  return (
    <>
      <header className="border-border/40 bg-background/85 sticky top-0 z-50 border-b backdrop-blur-md">
        <div className="mx-auto flex h-16 w-full max-w-7xl items-center gap-4 px-4 sm:px-6 lg:h-18 lg:px-8">
          <Link href="/" className="shrink-0">
            <BrandMark />
          </Link>

          <ActiveSectionNav className="mx-auto hidden items-center gap-8 lg:flex xl:gap-11" />

          <div className="ml-auto flex items-center gap-3 lg:ml-0 lg:gap-6">
            <LanguageSwitcher variant="nav" className="hidden lg:inline-flex" />

            <Button
              asChild
              variant="gradient"
              className="h-11 px-5 text-sm leading-[1.2] tracking-[-0.03em] lg:h-12 lg:px-7 lg:text-base"
            >
              {/* Short label on narrow screens — the full ua/ru string overflows 360 px. */}
              <a {...ctaLinkProps} aria-label={t("openBot")}>
                <SendIcon className="size-4" />
                <span className="sm:hidden">{t("openBotShort")}</span>
                <span className="hidden sm:inline">{t("openBot")}</span>
              </a>
            </Button>

            <MobileNav />
          </div>
        </div>
      </header>

      <PromoBar />
    </>
  );
}
