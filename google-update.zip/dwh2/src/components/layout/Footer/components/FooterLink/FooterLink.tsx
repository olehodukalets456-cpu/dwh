import { Link } from "@/i18n/navigation";
import type { FooterLink as FooterLinkData } from "../../types";

const TEXT_CLASS = "text-muted-foreground inline-flex items-center gap-2 text-sm";
const LINK_CLASS = `${TEXT_CLASS} hover:text-foreground focus-visible:text-foreground transition-colors`;

type FooterLinkProps = {
  link: FooterLinkData;
  /** Pre-resolved label — keeps this renderer free of the i18n namespace. */
  label: string;
};

/**
 * Renders one footer link by its kind. Internal links with no href render nothing (not-yet-built
 * routes never surface as dead links); external links with no href render as static text — the
 * channel/support contacts are shown per design even before a real URL exists.
 */
export function FooterLink({ link, label }: FooterLinkProps) {
  const { icon: Icon } = link;
  const content = (
    <>
      {Icon ? <Icon className="size-4 shrink-0" aria-hidden /> : null}
      <span>{label}</span>
    </>
  );

  if (link.kind === "internal") {
    if (!link.href) return null;
    return (
      <Link href={link.href} className={LINK_CLASS}>
        {content}
      </Link>
    );
  }

  if (link.kind === "external") {
    if (!link.href) return <span className={TEXT_CLASS}>{content}</span>;
    return (
      <a href={link.href} target="_blank" rel="noopener noreferrer" className={LINK_CLASS}>
        {content}
      </a>
    );
  }

  return (
    <a href={link.href} className={LINK_CLASS}>
      {content}
    </a>
  );
}
