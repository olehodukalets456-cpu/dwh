export { FooterLink } from "./FooterLink";
