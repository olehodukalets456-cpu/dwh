import { GlobeIcon, HeadsetIcon, SendIcon } from "lucide-react";
import { EXTERNAL_LINKS } from "@/constants/links";
import { SECTION_IDS, sectionHref } from "@/constants/sections";
import type { FooterLinkGroup } from "./types";

/** TODO(shop): point `privacy`/`refund` at their own routes once that copy exists; `undefined`
 * hrefs are skipped by the renderer rather than shipping links to 404s. Refund terms live
 * inside the ToS document (`/terms#refund`) today, so no separate nav entry for them. */
const LEGAL_HREFS = {
  terms: "/terms",
  privacy: undefined,
  refund: undefined,
} as const;

/** Unconfigured `NEXT_PUBLIC_*` vars render these as static text (per design) rather than
 * dead links — see `.env.example` for the three optional contact URLs. */
export const FOOTER_LINK_GROUPS = [
  {
    id: "navigate",
    titleKey: "groups.navigate",
    links: [
      { kind: "anchor", href: sectionHref(SECTION_IDS.advantages), labelKey: "links.whyUs" },
      { kind: "anchor", href: sectionHref(SECTION_IDS.pricing), labelKey: "links.pricing" },
      { kind: "anchor", href: sectionHref(SECTION_IDS.faq), labelKey: "links.faq" },
    ],
  },
  {
    id: "contacts",
    titleKey: "groups.contacts",
    links: [
      { kind: "external", href: EXTERNAL_LINKS.telegramBot, labelKey: "links.telegramBot", icon: GlobeIcon },
      { kind: "external", href: EXTERNAL_LINKS.telegramChannel, labelKey: "links.telegramChannel", icon: SendIcon },
      { kind: "external", href: EXTERNAL_LINKS.support, labelKey: "links.support", icon: HeadsetIcon },
    ],
  },
  {
    id: "legal",
    titleKey: "groups.legal",
    links: [
      { kind: "internal", href: LEGAL_HREFS.terms, labelKey: "links.terms" },
      { kind: "internal", href: LEGAL_HREFS.privacy, labelKey: "links.privacy" },
      { kind: "internal", href: LEGAL_HREFS.refund, labelKey: "links.refund" },
    ],
  },
] as const satisfies readonly FooterLinkGroup[];
