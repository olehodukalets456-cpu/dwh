import { SendIcon } from "lucide-react";
import { useTranslations } from "next-intl";
import { BrandMark } from "@/components/BrandMark";
import { Button } from "@/components/ui/button";
import { getCtaLinkProps, PRIMARY_CTA_HREF } from "@/constants/links";
import { FooterLink } from "./components/FooterLink";
import { FOOTER_LINK_GROUPS } from "./constants";
import type { FooterLink as FooterLinkData } from "./types";

/** Anchors and external links always render (external falls back to static text without a
 * real href); internal links stay hidden until they carry a real href. */
const isRenderable = (link: FooterLinkData) => link.kind !== "internal" || Boolean(link.href);

/**
 * Renders on every page including /not-found and /error, so it only depends on the
 * always-available `footer`/`common` namespaces, never landing-only data.
 */
export function Footer() {
  const t = useTranslations("footer");
  const year = new Date().getFullYear();
  const ctaLinkProps = getCtaLinkProps(PRIMARY_CTA_HREF);

  const groups = FOOTER_LINK_GROUPS.map((group) => ({
    ...group,
    links: group.links.filter(isRenderable),
  })).filter((group) => group.links.length > 0);

  return (
    <footer className="border-border/60 bg-card/30 border-t">
      <div className="mx-auto w-full max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-12 lg:flex-row lg:flex-wrap lg:items-start lg:justify-between">
          <div className="max-w-sm space-y-4">
            <BrandMark />
            <p className="text-muted-foreground text-sm text-pretty">{t("description")}</p>
          </div>

          <div className="flex flex-col gap-10 min-[480px]:flex-row min-[480px]:gap-12 lg:gap-16">
            {groups.map((group) => (
              <nav key={group.id} aria-label={t(group.titleKey)} className="flex flex-col gap-3">
                <h2 className="text-foreground text-xs font-semibold tracking-[0.14em] uppercase">
                  {t(group.titleKey)}
                </h2>
                <ul className="flex flex-col gap-2.5">
                  {group.links.map((link) => (
                    <li key={link.labelKey}>
                      <FooterLink link={link} label={t(link.labelKey)} />
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>

          <div className="lg:self-center">
            <Button asChild variant="gradient" className="h-11 px-6 text-sm">
              <a {...ctaLinkProps} aria-label={t("openChannel")}>
                <SendIcon className="size-4" aria-hidden />
                {t("openChannel")}
              </a>
            </Button>
          </div>
        </div>

        <div className="border-border/60 mt-12 flex flex-col gap-2 border-t pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-muted-foreground font-mono text-xs tracking-wide uppercase">
            {t("copyright", { year })}
          </p>
          {/* Full `muted-foreground` (not a faded `/70`) — at 12px the faded variant measured
              4.02:1 against the footer's card background, under the WCAG AA 4.5:1 floor. */}
          <p className="text-muted-foreground font-mono text-xs tracking-wide uppercase">{t("bottomNote")}</p>
        </div>
      </div>
    </footer>
  );
}
