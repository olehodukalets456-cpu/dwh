import type { LucideIcon } from "lucide-react";

/**
 * Discriminated by render kind (anchor/internal/external). `href` is optional on
 * internal/external since not-yet-built routes are skipped at render, never linked as a 404.
 */
type FooterLinkBase = {
  labelKey: string;
  icon?: LucideIcon;
};

export type FooterLink =
  | ({ kind: "anchor"; href: string } & FooterLinkBase)
  | ({ kind: "internal"; href?: string } & FooterLinkBase)
  | ({ kind: "external"; href?: string } & FooterLinkBase);

export type FooterLinkGroup = {
  id: string;
  titleKey: string;
  links: readonly FooterLink[];
};
