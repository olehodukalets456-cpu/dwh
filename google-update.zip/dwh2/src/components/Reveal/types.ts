import type { ReactNode } from "react";

export type RevealProps = {
  children: ReactNode;
  className?: string;
  /** Stagger offset in milliseconds, for revealing siblings in sequence. */
  delayMs?: number;
};
