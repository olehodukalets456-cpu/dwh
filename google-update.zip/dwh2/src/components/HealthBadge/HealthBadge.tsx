"use client";

import { useHealth } from "@/api/health";
import { cn } from "@/lib/utils";

const STATUS_COLOR = {
  ok: "bg-emerald-500",
  degraded: "bg-amber-500",
  down: "bg-red-500",
} as const;

/**
 * Sample consumer of the api-layer pattern — proves the TanStack Query provider is wired.
 * Replace or delete once real domains exist.
 */
export function HealthBadge() {
  const { data, isSuccess } = useHealth();

  if (!isSuccess) return null;

  return (
    <span className="text-muted-foreground flex items-center gap-1.5 text-xs" title={`API ${data.status}`}>
      <span className={cn("size-1.5 rounded-full", STATUS_COLOR[data.status])} />v{data.version}
    </span>
  );
}
