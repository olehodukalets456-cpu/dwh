import { cva } from "class-variance-authority";
import { cn } from "@/lib/utils";
import type { SectionHeadingProps } from "./types";

const headingVariants = cva("font-semibold tracking-[-0.05em] text-balance uppercase", {
  variants: {
    size: {
      default: "text-3xl sm:text-5xl lg:text-6xl",
      lg: "text-4xl sm:text-6xl lg:text-7xl",
    },
  },
  defaultVariants: { size: "default" },
});

/** Eyebrow / title / description block shared by every landing section. */
export function SectionHeading({
  title,
  titleAccent,
  titleRest,
  eyebrow,
  description,
  as: Heading = "h2",
  align = "center",
  size = "default",
  className,
}: SectionHeadingProps) {
  return (
    <div
      className={cn(
        "flex max-w-3xl flex-col gap-10",
        align === "center" ? "mx-auto items-center text-center" : "items-start text-left",
        className,
      )}
    >
      {eyebrow ? (
        <span className="text-primary tracking-wide uppercase [&_[data-slot=badge]]:text-lg!">{eyebrow}</span>
      ) : null}
      <Heading className={cn(headingVariants({ size }))}>
        {title ?? (
          <>
            <span className="from-primary to-primary-accent block bg-linear-to-r bg-clip-text text-transparent [-webkit-background-clip:text]">
              {titleAccent}
            </span>
            <span className="block">{titleRest}</span>
          </>
        )}
      </Heading>
      {description ? (
        <p className="text-muted-foreground max-w-[600] text-lg leading-[1.2] font-medium text-pretty">{description}</p>
      ) : null}
    </div>
  );
}
