import type { ReactNode } from "react";

export type SectionHeadingProps = {
  /** Full custom title markup. Prefer `titleAccent`/`titleRest` for the standard two-line pattern. */
  title?: ReactNode;
  /** First title line, rendered in the primary accent color. */
  titleAccent?: ReactNode;
  /** Second title line, rendered in the default text color. */
  titleRest?: ReactNode;
  /** Small label above the title (kicker/overline). */
  eyebrow?: ReactNode;
  description?: ReactNode;
  /**
   * Heading level. Defaults to `h2` — the page's single `h1` belongs to the hero,
   * and skipping levels breaks the document outline.
   */
  as?: "h1" | "h2" | "h3";
  align?: "left" | "center";
  size?: "default" | "lg";
  className?: string;
};
