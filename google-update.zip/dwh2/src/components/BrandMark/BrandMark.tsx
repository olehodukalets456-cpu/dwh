import Image from "next/image";
import { useTranslations } from "next-intl";

export function BrandMark() {
  const t = useTranslations("common");

  return (
    <span className="flex items-center gap-2.5">
      <span
        aria-hidden
        className="border-border/70 bg-card flex size-10 shrink-0 items-center justify-center overflow-hidden rounded-xl border"
      >
        <Image src="/logo.png" alt="" width={40} height={40} className="size-full object-cover" priority />
      </span>

      <span className="flex flex-col justify-center leading-none">
        <span className="text-foreground text-lg font-bold tracking-tight">{t("brand")}</span>
        <span className="text-muted-foreground mt-1 hidden text-[9px] font-medium tracking-[0.18em] uppercase sm:block">
          {t("tagline")}
        </span>
      </span>
    </span>
  );
}
