export type LanguageSwitcherProps = {
  /** `nav` renders a bare uppercase label to sit inline with header nav links. */
  variant?: "default" | "nav";
  className?: string;
};
