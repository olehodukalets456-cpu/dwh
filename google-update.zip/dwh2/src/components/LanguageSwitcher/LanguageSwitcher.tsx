"use client";

import { ChevronDownIcon, GlobeIcon } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";
import { useTransition } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { usePathname, useRouter } from "@/i18n/navigation";
import { type Locale, routing } from "@/i18n/routing";
import { cn } from "@/lib/utils";
import type { LanguageSwitcherProps } from "./types";

export function LanguageSwitcher({ variant = "default", className }: LanguageSwitcherProps = {}) {
  const t = useTranslations("common");
  const locale = useLocale();
  const router = useRouter();
  const pathname = usePathname();
  const [isPending, startTransition] = useTransition();

  // `pathname` from @/i18n/navigation excludes the locale prefix, so replacing it with a new
  // locale keeps the user on the same page. Dynamic routes need the `{ pathname, params }` form.
  const selectLocale = (nextLocale: Locale) => {
    startTransition(() => {
      router.replace(pathname, { locale: nextLocale });
    });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          aria-label={t("language.label")}
          disabled={isPending}
          className={cn(
            variant === "nav" &&
              "text-muted-foreground hover:text-foreground h-auto px-0 text-xs font-medium tracking-[0.14em] uppercase hover:bg-transparent",
            className,
          )}
        >
          {variant === "default" && <GlobeIcon className="size-4" />}
          <span className="uppercase">{locale}</span>
          <ChevronDownIcon className="size-3.5 opacity-60" aria-hidden />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {routing.locales.map((item) => (
          <DropdownMenuItem key={item} onSelect={() => selectLocale(item)} disabled={item === locale}>
            {t(`language.${item}`)}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
