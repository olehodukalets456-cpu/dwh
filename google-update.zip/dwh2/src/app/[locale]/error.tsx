"use client";

import { useTranslations } from "next-intl";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const t = useTranslations("common");

  useEffect(() => {
    // Replace with the error-tracking client (e.g. Sentry) once one is wired up.
    console.error(error);
  }, [error]);

  return (
    <main id="main-content" className="flex flex-1 flex-col items-center justify-center gap-6 px-4 py-24 text-center">
      <h1 className="text-2xl font-semibold tracking-tight">{t("error.title")}</h1>
      <p className="text-muted-foreground max-w-md text-pretty">{t("error.description")}</p>
      <Button onClick={reset}>{t("actions.retry")}</Button>
    </main>
  );
}
