import { ImageResponse } from "next/og";
import { buildOgImageElement, OG_IMAGE_CONTENT_TYPE, OG_IMAGE_SIZE } from "./_og/shared";

export const alt = "DWH HUB — Trusted domains with a clean history";
export const size = OG_IMAGE_SIZE;
export const contentType = OG_IMAGE_CONTENT_TYPE;

export default async function Image({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  return new ImageResponse(await buildOgImageElement(locale), size);
}
