import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { notFound } from "next/navigation";
import { hasLocale, NextIntlClientProvider } from "next-intl";
import { getMessages, getTranslations, setRequestLocale } from "next-intl/server";
import type { ReactNode } from "react";
import { env } from "@/config/env";
import { EXTERNAL_LINKS } from "@/constants/links";
import { routing } from "@/i18n/routing";
import { serializeJsonLd } from "@/lib/jsonLd";
import { AppProviders } from "@/providers";
import "../globals.css";

const geist = Geist({
  subsets: ["latin", "cyrillic"],
  variable: "--font-sans",
  display: "swap",
});
const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-geist-mono",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(env.NEXT_PUBLIC_SITE_URL),
  title: { default: "DWH HUB", template: "%s · DWH HUB" },
  description: "Trusted domains with a clean history.",
};

export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;

  if (!hasLocale(routing.locales, locale)) notFound();

  // Opts this tree into static rendering — must run before any translation call.
  setRequestLocale(locale);

  const [messages, tCommon] = await Promise.all([getMessages(), getTranslations({ locale, namespace: "common" })]);

  const siteUrl = env.NEXT_PUBLIC_SITE_URL;
  const localeUrl = `${siteUrl}/${locale}`;
  const organizationJsonLd = serializeJsonLd({
    "@context": "https://schema.org",
    "@type": "Organization",
    name: tCommon("brand"),
    url: siteUrl,
    sameAs: [EXTERNAL_LINKS.telegramBot],
  });
  const websiteJsonLd = serializeJsonLd({
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: tCommon("brand"),
    url: localeUrl,
  });

  return (
    <html
      lang={locale}
      className={`${geist.variable} ${geistMono.variable} dark h-full antialiased`}
      suppressHydrationWarning
    >
      <body className="flex min-h-full flex-col">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: organizationJsonLd }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: websiteJsonLd }} />

        {/* `Reveal` hides its children until an IntersectionObserver fires. Without JS that
            never happens, so the content would stay invisible — one rule keeps it readable. */}
        <noscript>
          <style dangerouslySetInnerHTML={{ __html: "[data-reveal]{opacity:1!important;transform:none!important}" }} />
        </noscript>

        <a
          href="#main-content"
          className="bg-primary text-primary-foreground focus-visible:ring-ring sr-only z-100 rounded-full px-5 py-3 text-sm font-semibold focus-visible:not-sr-only focus-visible:fixed focus-visible:top-4 focus-visible:left-4 focus-visible:ring-3 focus-visible:outline-none"
        >
          {tCommon("skipToContent")}
        </a>

        <NextIntlClientProvider messages={messages}>
          <AppProviders>{children}</AppProviders>
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
