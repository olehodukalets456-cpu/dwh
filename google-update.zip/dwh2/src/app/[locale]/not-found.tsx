import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Link } from "@/i18n/navigation";

export default function NotFoundPage() {
  const t = useTranslations("common");

  return (
    <main id="main-content" className="flex flex-1 flex-col items-center justify-center gap-6 px-4 py-24 text-center">
      <p className="text-primary text-6xl font-semibold">404</p>
      <h1 className="text-2xl font-semibold tracking-tight">{t("notFound.title")}</h1>
      <p className="text-muted-foreground max-w-md text-pretty">{t("notFound.description")}</p>
      <Button asChild>
        <Link href="/">{t("notFound.backHome")}</Link>
      </Button>
    </main>
  );
}
