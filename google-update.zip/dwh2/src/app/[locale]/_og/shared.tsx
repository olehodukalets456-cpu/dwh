import { getTranslations } from "next-intl/server";

export const OG_IMAGE_SIZE = { width: 1200, height: 630 };
export const OG_IMAGE_CONTENT_TYPE = "image/png";

/**
 * Satori cannot read CSS custom properties, so this palette is a fixed hex approximation
 * of the dark theme tokens — the one sanctioned literal-color spot in the codebase.
 */
export async function buildOgImageElement(locale: string) {
  const t = await getTranslations({ locale, namespace: "common" });

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 24,
        background: "linear-gradient(135deg, #0f1620 0%, #182430 100%)",
        color: "#f1f6f7",
        fontFamily: "sans-serif",
      }}
    >
      <div style={{ display: "flex", fontSize: 30, letterSpacing: 6, textTransform: "uppercase", color: "#5fd0e0" }}>
        {t("brand")}
      </div>
      <div style={{ display: "flex", fontSize: 58, fontWeight: 700, textAlign: "center", maxWidth: 900 }}>
        {t("tagline")}
      </div>
    </div>
  );
}
