import { notFound } from "next/navigation";

/**
 * Catches unmatched paths inside a locale so they render the localized `not-found.tsx`
 * instead of Next's untranslated global 404.
 */
export default function CatchAllPage() {
  notFound();
}
