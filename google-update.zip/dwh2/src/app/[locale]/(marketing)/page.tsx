import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { LandingPage } from "@/features/landing";
import { routing } from "@/i18n/routing";

type Props = { params: Promise<{ locale: string }> };

/**
 * Title/description are pulled from copy the page already renders (hero headline, footer
 * blurb) rather than new catalog entries, so metadata can never drift from visible text.
 */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const [tHero, tFooter] = await Promise.all([
    getTranslations({ locale, namespace: "landing-hero" }),
    getTranslations({ locale, namespace: "footer" }),
  ]);

  const title = `${tHero("titleAccent")} ${tHero("titleRest")}`;
  const description = tFooter("description");
  const canonicalPath = `/${locale}`;
  // Custom `openGraph`/`twitter` objects replace, not merge with, Next's auto-detected
  // file-convention image, so the path must be referenced explicitly here.
  const shareImagePath = `/${locale}/opengraph-image`;

  return {
    title,
    description,
    alternates: {
      canonical: canonicalPath,
      languages: {
        ...Object.fromEntries(routing.locales.map((l) => [l, `/${l}`])),
        "x-default": `/${routing.defaultLocale}`,
      },
    },
    openGraph: {
      title,
      description,
      url: canonicalPath,
      siteName: "DWH HUB",
      locale,
      type: "website",
      images: [shareImagePath],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [shareImagePath],
    },
  };
}

export default async function HomePage({ params }: Props) {
  const { locale } = await params;

  // Opts this route into static rendering — must run before any translation call.
  setRequestLocale(locale);

  return <LandingPage />;
}
