import { setRequestLocale } from "next-intl/server";
import type { ReactNode } from "react";
import { FreeDomainPopup } from "@/components/FreeDomainPopup";
import { Footer } from "@/components/layout/Footer";
import { Navbar } from "@/components/layout/Navbar";

/**
 * A future `(shop)` route group gets its own layout beside this one — catalog and
 * checkout need a different header (cart, account).
 */
export default async function MarketingLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;

  // Navbar and Footer translate at this level, so this layout needs its own
  // setRequestLocale — without it the whole segment silently opts out of static rendering.
  setRequestLocale(locale);

  return (
    <>
      <Navbar />
      <main id="main-content" className="flex flex-1 flex-col">
        {children}
      </main>
      <Footer />
      <FreeDomainPopup />
    </>
  );
}
