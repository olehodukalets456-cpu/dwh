import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { TermsPage } from "@/features/legal/terms";
import { routing } from "@/i18n/routing";

type Props = { params: Promise<{ locale: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "legal-terms" });

  const title = t("title");
  const canonicalPath = `/${locale}/terms`;

  return {
    title,
    description: t("intro"),
    alternates: {
      canonical: canonicalPath,
      languages: {
        ...Object.fromEntries(routing.locales.map((l) => [l, `/${l}/terms`])),
        "x-default": `/${routing.defaultLocale}/terms`,
      },
    },
  };
}

export default async function Terms({ params }: Props) {
  const { locale } = await params;

  setRequestLocale(locale);

  return <TermsPage />;
}
