import type { MetadataRoute } from "next";
import { env } from "@/config/env";
import { routing } from "@/i18n/routing";

/**
 * Every locale variant is its own entry (required by `localePrefix: "always"`), mirroring
 * the hreflang set in the page's `generateMetadata`.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const siteUrl = env.NEXT_PUBLIC_SITE_URL;

  const languages = Object.fromEntries([
    ...routing.locales.map((locale) => [locale, `${siteUrl}/${locale}`] as const),
    ["x-default", `${siteUrl}/${routing.defaultLocale}`] as const,
  ]);

  const termsLanguages = Object.fromEntries([
    ...routing.locales.map((locale) => [locale, `${siteUrl}/${locale}/terms`] as const),
    ["x-default", `${siteUrl}/${routing.defaultLocale}/terms`] as const,
  ]);

  return routing.locales.flatMap((locale) => [
    {
      url: `${siteUrl}/${locale}`,
      lastModified: new Date(),
      changeFrequency: "weekly",
      priority: locale === routing.defaultLocale ? 1 : 0.9,
      alternates: { languages },
    },
    {
      url: `${siteUrl}/${locale}/terms`,
      lastModified: new Date(),
      changeFrequency: "monthly",
      priority: 0.3,
      alternates: { languages: termsLanguages },
    },
  ]);
}
