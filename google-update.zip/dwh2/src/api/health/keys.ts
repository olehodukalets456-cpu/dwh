import { KeyFactory } from "@/lib/keyFactory";

class HealthKeys extends KeyFactory {
  constructor() {
    super("health");
  }

  status() {
    return this.createKey("status");
  }
}

export const healthKeys = new HealthKeys();
