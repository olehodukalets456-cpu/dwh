import type { HealthStatus } from "./types";

/**
 * Sample domain service demonstrating the layer pattern (keys → service → hook).
 * There is no backend yet, so `getStatus` returns a mocked payload.
 */
class HealthService {
  getStatus = async (): Promise<HealthStatus> => {
    return { status: "ok", version: "0.1.0" };
  };
}

export const healthService = new HealthService();
