import { useQuery } from "@tanstack/react-query";
import { healthKeys } from "../keys";
import { healthService } from "../service";

export const useHealth = () =>
  useQuery({
    queryKey: healthKeys.status(),
    queryFn: healthService.getStatus,
    staleTime: 1000 * 60 * 5,
  });
