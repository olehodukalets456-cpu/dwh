/** Subclass per domain: `.all` is the domain root key, `createKey(...)` appends segments —
 * keeps a query and its prefetch/invalidation from drifting apart. */
export class KeyFactory {
  readonly #baseKey: string;

  constructor(baseKey: string) {
    this.#baseKey = baseKey;
  }

  protected createKey<T extends readonly unknown[]>(...segments: T) {
    return [this.#baseKey, ...segments] as const;
  }

  get all() {
    return [this.#baseKey] as const;
  }
}
