import { defaultShouldDehydrateQuery, isServer, QueryClient } from "@tanstack/react-query";

// Statuses where a retry is pointless (client/validation errors) — bail immediately.
const NO_RETRY_STATUSES = new Set([400, 401, 403, 404, 409, 422]);

function makeQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 30_000,
        refetchOnWindowFocus: false,
        retry: (failureCount, error) => {
          const status = (error as { response?: { status?: number } })?.response?.status;
          if (status && NO_RETRY_STATUSES.has(status)) return false;
          return failureCount < 3;
        },
      },
      dehydrate: {
        // Include pending queries so streamed SSR prefetches hydrate on the client.
        shouldDehydrateQuery: (query) => defaultShouldDehydrateQuery(query) || query.state.status === "pending",
      },
    },
  });
}

let browserQueryClient: QueryClient | undefined;

/** On the server, a fresh client per request (no cross-request leakage); in the browser,
 * a singleton so state survives Suspense/re-renders. */
export function getQueryClient() {
  if (isServer) return makeQueryClient();
  browserQueryClient ??= makeQueryClient();
  return browserQueryClient;
}
