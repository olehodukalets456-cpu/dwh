/** Escapes `<` so a serialized JSON-LD payload cannot break out of its surrounding `</script>` tag. */
export function serializeJsonLd(data: unknown): string {
  return JSON.stringify(data).replace(/</g, "\\u003c");
}
