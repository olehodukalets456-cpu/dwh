import { z } from "zod";

/**
 * Shared Zod primitives for forms. Store i18n **message keys** (e.g. "common:validation.required")
 * in errors — never literal UI text — and let the form field components resolve them via `t()` at render.
 */
export const requiredString = (message = "common:validation.required") => z.string().trim().min(1, { message });

export const optionalString = () => z.string().trim().optional();

export const requiredNumber = (message = "common:validation.required") =>
  z.number({ message }).or(z.string().min(1, { message }).transform(Number));

export const emailString = (message = "common:validation.email") => z.string().trim().email({ message });
