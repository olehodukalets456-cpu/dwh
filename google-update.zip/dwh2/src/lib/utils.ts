import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Fills a `:param` route mask with values, e.g. getItemPath("/products/:id", { id: 7 }). */
export function getItemPath(route: string, params: Record<string, string | number>) {
  return route.replace(/:(\w+)/g, (_, key: string) => String(params[key]));
}

/** Triggers a browser download for a URL (client-only). */
export function downloadFile(fileUrl: string, fileName?: string) {
  const defaultFileName = fileUrl.split("\\").pop()?.split("/").pop() || "file";
  const link = document.createElement("a");
  link.href = fileUrl;
  link.setAttribute("download", fileName || defaultFileName);
  document.body.appendChild(link);
  link.click();
  link.remove();
}
