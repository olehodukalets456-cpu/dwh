/**
 * Reads a human-readable message off an unknown thrown value.
 * Central place to normalize error display — extend when the backend error envelope is known.
 */
export function getErrorMessage(error: unknown, fallback = "Something went wrong"): string {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === "string" && error) return error;
  return fallback;
}
