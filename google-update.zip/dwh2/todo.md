# TODO

## Hero background: заменить SVG-имитацию на растр из макета

Файл: `src/features/landing/hero/components/HeroBackdrop/HeroBackdrop.tsx`
Изображение: `public/landing/hero/bg.png` (1440×980, ~1.19 МБ)

Сейчас фон нарисован вручную через SVG (точечная сетка + дуги) + CSS-градиенты — сознательно, без растра,
потому что `Hero` является LCP-элементом страницы: картинка добавляет сетевой запрос и может вызвать CLS,
если её intrinsic-размеры не совпадают с зарезервированным местом.

Вариант замены (если решим использовать реальный макетный фон):

```tsx
import Image from "next/image";
import bg from "../../../../../../public/landing/hero/bg.png";

export function HeroBackdrop() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      <Image src={bg} alt="" fill priority sizes="100vw" className="object-cover object-top" />
      <div className="to-background absolute inset-x-0 bottom-0 h-32 bg-gradient-to-b from-transparent" />
    </div>
  );
}
```

Использует `next/image` с `priority` (т.к. это LCP-элемент) — Next оптимизирует формат (webp/avif) и ресайз
под вьюпорт, но всё равно тяжелее, чем текущий inline SVG/CSS без сетевого запроса.

### Открытые вопросы перед внедрением

- Сжать/уменьшить `bg.png` перед использованием (1.19 МБ многовато даже с оптимизацией Next)?
- Точное визуальное соответствие макету vs гарантированно быстрый первый экран — что важнее для этой секции?
- Проверить LCP/CLS в реальных условиях (Lighthouse) после замены, прежде чем мержить.