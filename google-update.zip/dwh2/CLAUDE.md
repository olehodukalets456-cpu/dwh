@AGENTS.md

# CLAUDE.md — dwh-hub-shop

Project-level instructions. These override the global `~/.claude/CLAUDE.md` where they conflict.

## What This Project Is

Next.js 16 (App Router) + React 19 + TypeScript marketing site for **DWH HUB** — a service selling aged domains with a clean history. Three locales: **en** (default) / **ua** / **ru**.

The current deliverable is a **landing page**. The architecture is deliberately shaped so it can grow into a **shop** (catalog / cart / checkout) without restructuring — see [Scaling to a Shop](#scaling-to-a-shop).

Architecture and conventions are adapted from the sibling project `DmndHelperFront` (a Vite + React Router SPA). The API layer, query-key factory, folder-per-component layout, and form patterns are ported as-is; **routing, i18n, and data fetching differ** because this is Next.js — see [Differences From the Reference Project](#differences-from-the-reference-project).

## Commands

```bash
npm run dev           # dev server (Turbopack) on http://localhost:3000
npm run build         # production build
npm run typecheck     # tsc --noEmit
npm run lint          # eslint
npm run lint:fix      # eslint --fix
npm run format        # prettier --write .
npm run check:messages # locale parity across /messages
```

**Before finishing any change:** run `npm run typecheck && npm run lint && npm run check:messages`.

Add a shadcn component: `npx shadcn@latest add <component>`.

## Folder Structure

```
messages/                  # translation CONTENT — <locale>/<namespace>.json
scripts/                   # repo tooling — checkMessages.mjs
src/
  app/
    globals.css            # Tailwind v4 @theme + design tokens
    sitemap.ts · robots.ts # all-locale sitemap + crawler rules (locale-agnostic, live at app/ root)
    [locale]/
      layout.tsx           # ROOT layout — <html>, fonts, NextIntlClientProvider, AppProviders, Organization/WebSite JSON-LD, skip link
      opengraph-image.tsx  # per-locale share image (next/og); also serves as the twitter:image
      (marketing)/         # landing route group — layout.tsx (Navbar/Footer) + page.tsx (generateMetadata)
      [...rest]/page.tsx   # catch-all → localized notFound()
      not-found.tsx · error.tsx · loading.tsx
  i18n/                    # i18n CONFIG only — routing.ts · navigation.ts · request.ts
  config/env.ts            # zod-validated env, fails fast
  providers/               # AppProviders, QueryProvider
  api/
    client.ts              # typed fetch wrapper
    <domain>/              # keys.ts service.ts types.ts index.ts queries/ mutations/
  features/
    landing/               # LandingPage.tsx + one folder per section + components/
  components/
    ui/                    # shadcn-generated — never hand-edit
    layout/                # Navbar, Footer
    Section/ SectionHeading/ Reveal/   # landing layout primitives
    <SharedComponent>/     # folder-per-component
  lib/                     # utils, keyFactory, validation, error, queryClient, jsonLd (script-safe JSON-LD serialization)
  constants/               # sections.ts (anchor ids), links.ts (CTA destinations)
  hooks/ · types/
  proxy.ts                 # locale routing (Next 16 renamed `middleware` → `proxy`)
```

**Route groups carry the marketing/shop split.** The landing lives in `(marketing)/`, which owns the `Navbar`/`Footer` chrome; catalog and checkout get `(shop)/` beside it with their own layout (cart, account) and no file moves. Each group's layout needs its **own** `setRequestLocale` call — it translates, so without one the whole segment drops out of static rendering.

**Sections never hardcode a shared value.** Anchor ids come from `constants/sections.ts`, CTA destinations from `constants/links.ts` (`getCtaLinkProps` also supplies `target`/`rel` for external links). Both are the seams the shop migration turns.

**Translations live in `/messages`, not in `src/`** — they are content, not code. That keeps `src/i18n/` to three config files (so the folder's job is obvious), puts the catalogs where translators and TMS tooling expect them, and matches next-intl's own default. The folder is named for the concept (`i18n`), **not** for the library: swapping next-intl out must not force a rename.

**`app/[locale]/` stays thin** — route files wire params and compose `features/*`. Business logic and layout live in `features/` or `components/`, never in the route file.

There is **no `app/layout.tsx`** — `app/[locale]/layout.tsx` is the root layout (it renders `<html>`). This is the standard next-intl structure.

## Routing

- File-system routing under `src/app/[locale]/`. There is no central routes config (unlike the reference's `routesConfig.tsx`).
- **Always** import navigation APIs from `@/i18n/navigation` (`Link`, `redirect`, `usePathname`, `useRouter`), never from `next/link` / `next/navigation`. The locale-aware versions keep the `/en|/ua|/ru` prefix correct.
- `src/proxy.ts` runs next-intl's locale detection/redirect. Next 16 deprecated the `middleware` filename in favour of `proxy`; the exported handler is still `createMiddleware(routing)`.
- Every statically rendered page/layout must call `setRequestLocale(locale)` **before** any translation call, or the route silently opts out of static rendering.
- Route params are **async** in Next 16: `params: Promise<{ locale: string }>` → `const { locale } = await params`.

## Internationalization

next-intl with `localePrefix: "always"` — every locale is explicitly prefixed (`/en`, `/ua`, `/ru`), which keeps hreflang/SEO symmetric across languages.

- **Message files are namespaced per feature**: `/messages/<locale>/<namespace>.json`. `src/i18n/request.ts` merges them into `{ [namespace]: keys }`. Landing sections get **one namespace each** (`landing-hero`, `landing-pricing`, …) so sections can be built in parallel without contending on a single catalog.
- **Adding a namespace** = create the JSON in _all three_ locales, add its name to the `NAMESPACES` array in `src/i18n/request.ts`, **and** add it to the `Messages` type in `src/types/messages.d.ts`. Missing a locale breaks the build for that locale.
- **Keys are typed.** `src/types/messages.d.ts` augments next-intl's `AppConfig`, so `t("…")` autocompletes and an unknown key fails to compile instead of surfacing as a runtime `MISSING_MESSAGE`. `en` is the type source — add keys there first. (The file needs its `export {}`: without it the block declares an ambient module that _shadows_ next-intl instead of augmenting it.)
- **Locale parity is checked, not eyeballed.** Types only cover `en`; `npm run check:messages` fails on any key present in one locale and missing in another.
- `useTranslations(ns)` works in **both** Server and Client Components. In async Server Components use `await getTranslations(ns)`.
- `<html lang>` is set from the locale param — keep it that way (SEO + a11y).
- **Zod schemas must not import i18n.** Store a namespaced message key (`"common:validation.required"`) in `message`, and resolve it via `t()` in the field component at render.
- The layout passes **all** messages to `NextIntlClientProvider`. Measured at 10 namespaces × 3 locales: ~7.9 kB uncompressed for the largest locale, gzipping to low single-digit kB — not material, so it is intentionally not split per-namespace. Re-measure if the catalog grows substantially (e.g. shop namespaces landing) and narrow to what client components actually consume if it becomes material.

## Data Fetching

**Server Components are the default.** Fetch directly in the Server Component; do not add `'use client'` just to load data.

Use TanStack Query for client-side interactivity (mutations, polling, dependent/paginated queries, optimistic UI). To hand server-fetched data to a client component, prefetch on the server and wrap in `HydrationBoundary`:

```tsx
const queryClient = getQueryClient();
await queryClient.prefetchQuery({ queryKey: productKeys.list(), queryFn: productService.getProducts });

<HydrationBoundary state={dehydrate(queryClient)}>
  <ProductList />
</HydrationBoundary>;
```

`getQueryClient()` (`src/lib/queryClient.ts`) returns a fresh client per request on the server and a browser singleton on the client — never construct a `QueryClient` inline.

`QueryClient` defaults: `staleTime: 30s`, `refetchOnWindowFocus: false`, and **no retry** on 400/401/403/404/409/422.

> The reference project's hover-based `usePrefetchRoute` is a Vite/React-Router pattern and is **not** ported — Next handles route prefetching via `<Link>` automatically.

## API Layer

Every domain lives in `src/api/<domain>/` with a fixed structure (ported verbatim from the reference):

```
src/api/products/
  keys.ts       # KeyFactory subclass — query-key definitions
  service.ts    # class of typed calls + singleton export
  types.ts      # domain types and DTOs
  index.ts      # re-exports
  queries/      # one file per query hook
  mutations/    # one file per mutation hook
```

- `keys.ts` subclasses `KeyFactory` (`src/lib/keyFactory.ts`): `.all` is the domain root, `createKey(...)` appends segments.
- `service.ts` is a class of arrow-function methods calling `apiClient` (`src/api/client.ts`) — **never** call `fetch` directly from a hook or component.
- Hooks call service methods. One hook per file. Mutations invalidate the domain's `.all` key and toast via `sonner`.
- `src/api/health/` is a **sample domain** demonstrating the pattern; its service returns mock data because no backend exists yet. Delete it once real domains land.

## Naming Conventions

| Thing                             | Case                        | Example                                                     |
| --------------------------------- | --------------------------- | ----------------------------------------------------------- |
| Component files & their folders   | `PascalCase`                | `LanguageSwitcher/LanguageSwitcher.tsx`                     |
| Every other TS/TS module          | `camelCase`                 | `queryClient.ts`, `keyFactory.ts`, `useHealth.ts`, `env.ts` |
| Non-component directories         | `lowercase` (one word)      | `api/`, `lib/`, `hooks/`, `providers/`, `messages/`         |
| Translation namespaces            | `kebab-case`                | `messages/en/account-settings.json`                         |
| Variables & functions             | `camelCase`                 | `getQueryClient`                                            |
| Types & interfaces                | `PascalCase`, no `I` prefix | `HealthStatus`, not `IHealthStatus`                         |
| Constants (module-level literals) | `SCREAMING_SNAKE_CASE`      | `NAV_LINKS`, `NAMESPACES`                                   |

**Do not use kebab-case for source modules** — `queryClient.ts`, never `query-client.ts`. Two exceptions, both externally mandated, so don't "fix" them:

- **Next.js special files** must use the framework's exact names: `page.tsx`, `layout.tsx`, `not-found.tsx`, `globals.css`, `proxy.ts`.
- **`src/components/ui/*`** is shadcn-generated (`dropdown-menu.tsx`) — regenerate, never rename.

## Components

Every shared component gets its own folder:

```
ComponentName/
  index.ts            # export { ComponentName } from "./ComponentName"
  ComponentName.tsx   # named export: export function ComponentName()
  types.ts            # props type (when it takes props)
  components/ · constants/ · utils/
```

- Folder name matches the component name exactly. **Named** exports (route files are the exception — they need `default`).
- Push `'use client'` as far down the tree as possible. `Navbar` is a Server Component; `LanguageSwitcher`, `ThemeToggle`, `MobileNav`, `ActiveSectionNav`, `Reveal`, and `FaqAccordion` are the client islands. `HealthBadge` still exists (a sample component demonstrating a data-fetching client island) but is no longer rendered anywhere — delete it once `src/api/health/` is deleted per its own note.
- Tailwind + `cn()` from `@/lib/utils` only — no CSS modules.
- **Never hand-edit `src/components/ui/**`** — regenerate via `npx shadcn@latest add`.
- Direct named React imports (`import { useState } from "react"`), never `React.*`. React 19: `ref` is a regular prop, no `forwardRef`.

**Landing layout primitives** — every landing section composes these rather than rolling its own spacing:

- `Section` — `<section>` + container + vertical rhythm + `scroll-mt` clearing the sticky header. Its `id` prop is typed to `SECTION_IDS`, so a mistyped anchor does not compile.
- `SectionHeading` — eyebrow / title / description with `as`, `align`, `size`.
- `Reveal` — client scroll-in fade, **below the fold only** (animating the LCP element delays it). Deliberately no animation library: one fade-up does not justify ~40 kB on a marketing page's critical path. Handles `prefers-reduced-motion`; the `<noscript>` rule in the root layout keeps its children visible without JS.

## Forms

React Hook Form + Zod. Schema and inferred type live in the owning feature's `constants/schema.ts`; derive the type with `z.infer<typeof Schema>` — never hand-write it. Reuse the primitives in `src/lib/validation.ts`. Server errors go to `setError("root", …)`.

## Styling & Design Tokens

Tailwind CSS v4, CSS-first config. Tokens are CSS variables in `src/app/globals.css`: `:root` (light) and `.dark` (dark), mapped to Tailwind colors in `@theme inline`.

**The design is dark-first** — `defaultTheme="dark"` in `AppProviders`. The palette is deep blue-black surfaces with a cyan/teal accent (`--primary`).

The current token values are a seed approximating the Figma design. When implementing the landing, extract the real tokens from Figma and update the `:root`/`.dark` blocks — do **not** hardcode hex values in components.

Fonts: **Geist** for `--font-sans` and **Geist Mono** for `--font-mono` (both loaded with the `cyrillic` subset, required for ua/ru).

## TypeScript Conventions

- `strict: true`. **No `any`** — use `unknown` + narrowing or a precise type.
- No `I` prefix on interfaces. `import type {}` for type-only imports.
- Validate all external data at the boundary with Zod.
- Path alias `@/*` → `src/*`.

## Environment

Copy `.env.example` → `.env.local`. Variables are validated by Zod in `src/config/env.ts`, which **throws at import time** on invalid config.

Only `NEXT_PUBLIC_*` vars reach the browser — never put a secret behind that prefix. Reference them **statically** (`process.env.NEXT_PUBLIC_X`), never dynamically, or Next can't inline them.

## SEO

- The landing's `generateMetadata` (`(marketing)/page.tsx`) builds title/description from copy the page already renders (hero headline, footer blurb) rather than new catalog entries, so metadata can't drift from visible text. `alternates.languages` covers en/ua/ru + `x-default`, mechanical because of `localePrefix: "always"`.
- `metadataBase` lives on the root layout's static `metadata` export; per-route metadata composes relative paths against it.
- `opengraph-image.tsx` under `app/[locale]/` generates a per-locale share image via `next/og`'s `ImageResponse` (builder in `_og/shared.tsx`); the page's `generateMetadata` points both `openGraph.images` and `twitter.images` at it — Twitter's card renders the same asset, so there's no separate `twitter-image.tsx` to keep in sync. Defining a page-level `openGraph`/`twitter` object replaces rather than merges with Next's auto-detected file-convention image, which is why the path is referenced explicitly instead of left implicit. Satori (the renderer) cannot read CSS custom properties, so the palette in `_og/shared.tsx` is a fixed hex approximation of the dark theme tokens — the one sanctioned place in the codebase for a literal color value, because it sits outside the Tailwind/CSS-token system entirely.
- `Organization`/`WebSite` JSON-LD renders once in the root layout; `FAQPage` JSON-LD renders once in the FAQ section, built from the same constants array the accordion renders so structured data can't describe text the page doesn't show. Both use `src/lib/jsonLd.ts`'s `serializeJsonLd` to escape `<` before embedding in `<script>`.
- `app/sitemap.ts` and `app/robots.ts` are locale-agnostic (they live above `[locale]/`) and enumerate all three locale variants of every route with matching `alternates.languages`.

## Scaling to a Shop

The structure anticipates this; follow it rather than reorganizing:

- Split route groups: `app/[locale]/(marketing)/` for the landing, `app/[locale]/(shop)/` for catalog/cart/checkout.
- Add domains under `src/api/` (`products`, `cart`, `orders`, `auth`) using the same keys/service/hook pattern.
- Render catalog/product pages as **Server Components** (SEO-critical) with TanStack Query hydration for interactive bits.
- Mutations (cart, checkout) → **Server Actions** with Zod validation inside the action.
- Global client state (cart, session) → **Zustand**. Not installed yet; add it when there is real state to hold. Never mirror server data into it — that is TanStack Query's job.
- Per-route `generateMetadata` + hreflang alternates + JSON-LD for products.

## Differences From the Reference Project

`DmndHelperFront` is a Vite SPA; do not copy these parts of it:

| Reference (Vite SPA)                                   | Here (Next.js)                                               |
| ------------------------------------------------------ | ------------------------------------------------------------ |
| React Router + `routesConfig.tsx` + `RouteAccessGuard` | File-system routing; gating via `proxy.ts` + segment layouts |
| `react-i18next`, `useTranslate`, localStorage locale   | `next-intl`, locale in the URL                               |
| axios instance + interceptors                          | `apiClient` fetch wrapper (`src/api/client.ts`)              |
| Client-side fetching everywhere                        | Server Components first; TanStack Query for interactivity    |
| `usePrefetchRoute` hover prefetching                   | Next's built-in `<Link>` prefetch                            |
| Biome                                                  | ESLint + Prettier                                            |

## Key Constraints

- **Minimal comments.** Explain a non-obvious _why_ (a hidden constraint, workaround, or invariant); never narrate _what_ the code does or restate a name/type. Max **2 lines** per comment — if it needs more, the code or a linked doc should carry the rest, not the comment. No commented-out code. Default to zero comments; add one only when its absence would mislead or cost a reader real time.
- Cross-feature imports are forbidden — a module under `features/<a>/` must not import from `features/<b>/`. Shared code moves to `components/` or `lib/`.
- Prettier: 2-space indent, double quotes, semicolons, trailing commas, 120-char width, LF.
- This is **Next.js 16** — read `node_modules/next/dist/docs/` before relying on remembered APIs (see AGENTS.md).
