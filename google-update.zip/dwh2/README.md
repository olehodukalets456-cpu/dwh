# DWH HUB

Multilingual marketing site for DWH HUB, built to scale into a shop.

**Stack:** Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS v4 · shadcn/ui · next-intl · TanStack Query · React Hook Form + Zod

**Locales:** `en` (default) · `ua` · `ru` — always URL-prefixed (`/en`, `/ua`, `/ru`).

## Getting started

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000 — you'll be redirected to your detected locale.

## Scripts

| Command                     | Description                  |
| --------------------------- | ---------------------------- |
| `npm run dev`               | Dev server (Turbopack)       |
| `npm run build`             | Production build             |
| `npm run start`             | Serve the production build   |
| `npm run typecheck`         | `tsc --noEmit`               |
| `npm run check:messages`    | Locale parity in `/messages` |
| `npm run lint` / `lint:fix` | ESLint                       |
| `npm run format`            | Prettier                     |

## Project layout

```
messages/          translation content — <locale>/<namespace>.json
scripts/           repo tooling (locale parity check)
src/
  app/[locale]/    routes (thin — compose features); (marketing)/ holds the landing
  app/sitemap.ts · app/robots.ts   locale-agnostic SEO file conventions
  i18n/            next-intl config (routing / navigation / request)
  api/             domain API layer (keys / service / queries / mutations)
  features/        feature modules — landing/ composes one folder per section
  components/      ui/ (shadcn), layout/, Section / SectionHeading / Reveal, shared components
  lib/             utils, queryClient, validation, keyFactory
  constants/       section anchor ids, CTA destinations
  config/env.ts    zod-validated environment
  proxy.ts         locale routing
```

## Adding a translation

1. Add the key to `messages/{en,ua,ru}/<namespace>.json` — **all three** locales.
2. If it's a new namespace, add its name to `NAMESPACES` in `src/i18n/request.ts` **and** to the `Messages` type in `src/types/messages.d.ts`.
3. Read it with `useTranslations("<namespace>")` (or `await getTranslations` in async Server Components). Keys are typed against `en` — an unknown one is a compile error.
4. Run `npm run check:messages` to confirm the locales stayed in sync.

## Implementing the landing

Task breakdown and per-section prompts for parallel work live in [docs/landing-delegation.md](docs/landing-delegation.md).

## Conventions

See [CLAUDE.md](CLAUDE.md) for the full architecture guide — routing, i18n, data fetching, the API layer, component structure, and the path to shop functionality.
