# Landing implementation — delegation pack

Task breakdown + copy-paste prompts for delegating the DWH HUB landing to parallel Claude Code agents.

**How to use:** run **T0 alone and first**. Then T1–T9 can run in parallel (each owns disjoint files). T10 runs last, alone.
Every prompt below already starts with `Read docs/landing-delegation.md § Shared context…` — so you only paste the task block, not the whole context.

Attach the Figma screenshot of the relevant section to each prompt. The Figma MCP currently returns _"you don't have edit access to this file"_ for `dqFZWLNR0A9Css9znUNh4h`, so agents **cannot read the design themselves**. If you grant editor access, add this line to any prompt instead of the screenshot:

> Design source: Figma file `dqFZWLNR0A9Css9znUNh4h`, node `108:283869`. Use `get_design_context` / `get_variable_defs` / `get_screenshot` for this section's frame. Do not invent spacing or colors — read them.

---

## Shared context (agents: read this section before touching anything)

### The product

**DWH HUB** sells **aged domains with a clean history** — domains that pass moderation on Google Ads and META (Facebook) Ads. Buyers are media buyers / affiliate marketers. The current sales channel is a **Telegram bot**; this site is the marketing front for it.

### What this repo is right now

A **Next.js 16 App Router** infrastructure scaffold with zero landing content. Read `CLAUDE.md` (conventions — this is binding) and `AGENTS.md` (Next 16 is **not** the Next.js in your training data — read `node_modules/next/dist/docs/` before relying on remembered APIs).

Already built and working: locale routing (`/en`, `/ua`, `/ru`, always-prefixed) · next-intl with namespaced catalogs in `/messages` · TanStack Query with SSR-hydration wiring · next-themes (dark-first) · shadcn/ui · zod-validated env · domain API layer (`src/api/`) with `KeyFactory` · `Navbar` / `LanguageSwitcher` / `ThemeToggle`.

### The constraint that shapes every decision: this becomes a shop

The landing is phase 1. Phase 2 is a **catalog / cart / checkout** on the same codebase. Nothing you build may need restructuring for that. Concretely:

| Do this now                                                              | Because later                                                                      |
| ------------------------------------------------------------------------ | ---------------------------------------------------------------------------------- |
| Landing lives in the `(marketing)` route group                           | `(shop)` is added beside it with no file moves                                     |
| Section content shaped as typed data, not JSX literals                   | The same components render server-fetched products                                 |
| Every CTA reads its href from `src/constants/links.ts`                   | One file flips from "open Telegram bot" to `/[locale]/catalog`                     |
| Pricing/plan objects carry a stable `id` and mirror a future product DTO | Swapping the static constant for `productService.getProducts()` touches one module |
| Sections are Server Components                                           | Catalog pages are SEO-critical and must render on the server                       |
| Copy lives in `/messages`, never in TSX                                  | Product copy becomes CMS/DB-driven without hunting for hardcoded strings           |

**Do not** install Zustand, build a cart, add auth, or create `api/products` — that is phase 2. Just don't block it.

### Non-negotiable rules

1. **No hardcoded user-visible strings.** Everything through `useTranslations(ns)` / `await getTranslations(ns)`. Add keys to **all three** locales (`en`, `ua`, `ru`) or the build breaks for the missing one.
2. **No hardcoded colors, hex, or rgb.** Only design tokens (`bg-card`, `text-muted-foreground`, `border-border`, `text-primary`…) defined in `src/app/globals.css`. If a needed color has no token, add a token to **both** `:root` and `.dark` — never inline it.
3. **Server Components by default.** `'use client'` only for state / effects / event handlers / browser APIs, and pushed as far down the tree as possible. A section that is just markup must not be a client component.
4. **No `any`, no unsafe `as`.** `strict: true`. `import type {}` for type-only imports.
5. **Folder-per-component** (`CLAUDE.md § Components`): `ComponentName/{index.ts, ComponentName.tsx, types.ts, components/, constants/}`, named exports.
6. **Naming** (`CLAUDE.md § Naming Conventions`): `PascalCase` component files/folders, `camelCase` every other module (`sectionData.ts`, never `section-data.ts`), `kebab-case` translation namespaces.
7. **No cross-feature imports.** `features/landing/<a>` must not import from `features/landing/<b>`. Shared code goes to `features/landing/components/` (landing-wide) or `src/components/` (app-wide).
8. **Minimal comments.** Explain a non-obvious _why_. Never narrate _what_. No commented-out code.
9. **Only touch the files your task owns.** Other agents are working in parallel on the same repo. If you believe a shared file must change, stop and report it instead of editing.

### Definition of done (every task)

```bash
npm run typecheck && npm run lint && npm run check:messages && npm run build
```

All four clean. `check:messages` fails if a key exists in `en` but not in `ua`/`ru` (or vice versa) — TypeScript only types keys against `en`, so this is what catches a half-translated section. Then verify visually at 360 / 768 / 1280 px in **all three locales** (Ukrainian and Russian strings are ~20–30 % longer than English — layouts must not break) and in **both themes** (dark is primary; light must still be usable). Keyboard-navigable, visible focus rings, `prefers-reduced-motion` respected.

Report at the end: files created/changed, tokens added (if any), anything you deliberately deferred.

---

## Task list

| #   | Task                       | Depends on | Owns                                                                       |
| --- | -------------------------- | ---------- | -------------------------------------------------------------------------- |
| T0  | Foundation ✅ **done**     | —          | route group, section shell primitives, all namespaces, shadcn deps, tokens |
| T1  | Navbar + mobile nav        | T0         | `components/layout/Navbar/`                                                |
| T2  | Hero                       | T0         | `features/landing/hero/`                                                   |
| T3  | Advantages                 | T0         | `features/landing/advantages/`                                             |
| T4  | Compatibility              | T0         | `features/landing/compatibility/`                                          |
| T5  | Profit comparison          | T0         | `features/landing/profit/`                                                 |
| T6  | Pricing                    | T0         | `features/landing/pricing/`                                                |
| T7  | FAQ                        | T0         | `features/landing/faq/`                                                    |
| T8  | Final CTA                  | T0         | `features/landing/cta/`                                                    |
| T9  | Footer                     | T0         | `components/layout/Footer/`                                                |
| T10 | SEO · a11y · perf · polish | T1–T9      | metadata, JSON-LD, sitemap, robots, final pass                             |

**Why T0 must be alone:** it creates the section stubs _and_ the file that composes them. After T0, no section agent ever edits the composition file, `request.ts`, `package.json`, or `globals.css` — which is what makes T1–T9 safely parallel.

---

## T0 — Foundation ✅ done

Built and verified. T1–T9 inherit the following; **none of it is theirs to change.**

### Frozen files — do not edit in T1–T9

| File                                                                              | Why                                                                |
| --------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| `src/features/landing/LandingPage.tsx`                                            | Section order and composition. Each section renders only itself.   |
| `src/i18n/request.ts`                                                             | Every namespace is already registered.                             |
| `src/app/[locale]/layout.tsx` · `(marketing)/layout.tsx` · `(marketing)/page.tsx` | Route wiring, `setRequestLocale`, page chrome.                     |
| `src/constants/sections.ts` · `src/constants/links.ts`                            | Shared registries — read them, never redefine them.                |
| `src/components/Section/` · `SectionHeading/` · `Reveal/`                         | Shared primitives. Need a change? Report it, do not edit.          |
| `src/components/ui/**`                                                            | shadcn-generated; everything the sections need is installed.       |
| `package.json` · `src/app/globals.css`                                            | Dependencies are complete. Tokens have one exception, noted below. |

### What exists now

**Route group** — `src/app/[locale]/(marketing)/{layout,page}.tsx`. The layout renders `Navbar` → `<main>` → `Footer`; the page renders `<LandingPage />` and nothing else. A future `(shop)` group sits beside it with its own layout.

**Registries**

- `src/constants/sections.ts` — `SECTION_IDS` + `sectionHref(id)`. The `Section` primitive's `id` prop is typed to these, so a mistyped anchor does not compile.
- `src/constants/links.ts` — `PRIMARY_CTA_HREF` and `getCtaLinkProps(href?)`, which adds `target`/`rel` for external destinations automatically. Spread it onto an `<a>`; never hand-write a CTA href. Reads `NEXT_PUBLIC_TELEGRAM_BOT_URL`, and falls back to the pricing anchor when unset rather than emitting a dead link.

**Shared primitives** (`src/components/`)

- `Section` — `<section>` + container + vertical rhythm + `scroll-mt-20` (header measures 65 px; an anchor jump was verified to clear it). Every section wraps its content in this — it is what keeps eight independently built sections visually consistent.
- `SectionHeading` — eyebrow / title / description, with `as` for the heading level (defaults to `h2`), `align`, and `size`.
- `Reveal` — client-side scroll-in fade. **Below the fold only.** No animation library: the landing needs one fade-up, not orchestration or gestures, so a ~40 kB dependency did not earn a place on the critical path. `prefers-reduced-motion` is handled inside it, and a `<noscript>` rule in the root layout keeps revealed content visible without JS.

**shadcn components installed** — `accordion`, `card`, `badge`, `separator`, `tabs`, `table`, `avatar`, on top of the existing `button`, `dropdown-menu`, `sheet`, `sonner`, `tooltip`. Do not run the shadcn CLI — it rewrites shared config. If you genuinely need another primitive, report it.

**Translations** — one namespace per section, all registered, all three locales seeded: `landing-hero`, `landing-advantages`, `landing-compatibility`, `landing-profit`, `landing-pricing`, `landing-faq`, `landing-cta`, `footer` (alongside the existing `common` and `navigation`). You edit only your own namespace's three files, which is what makes parallel work safe.

**Typed keys** — `src/types/messages.d.ts` augments next-intl's `AppConfig`, so `t("…")` autocompletes and an unknown key is a compile error rather than a runtime `MISSING_MESSAGE`. Add keys to `en` first — it is the type source. Locale parity is enforced separately by `npm run check:messages`.

**Section stubs** — `src/features/landing/{hero,advantages,compatibility,profit,pricing,faq,cta}/`, each a Server Component rendering `Section` + `SectionHeading` with its namespace title. Replace the body of your own, but keep the export name and `index.ts` intact so `LandingPage.tsx` keeps resolving.

**Landing-shared components** — `src/features/landing/components/` is empty and exists for components that more than one section needs. Anything app-wide belongs in `src/components/` instead.

### Deliberately not done

**Design tokens.** The palette in `globals.css` is still a seeded approximation of the screenshot, not extracted from Figma — the Figma MCP is authorised under a different account and cannot read the file. If your section's design needs a token that does not exist, add it to **both** `:root` and `.dark`, map it in `@theme inline`, and say so in your report. This is the one sanctioned exception to "do not touch `globals.css`".

### Verified

`typecheck` · `lint` · `check:messages` · `build` all clean. `/en`, `/ua`, `/ru` prerender as static (`● /[locale]`), each rendering seven sections, exactly one `h1` and one `main`, a navbar whose five anchors all resolve to real section ids, and the footer. No console errors.

---

## T1 — Navbar + mobile navigation

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

Task: finish the site header. It exists as a shell at src/components/layout/Navbar/ — it renders the brand, desktop anchor links, LanguageSwitcher and ThemeToggle, but has no mobile navigation and no primary CTA.

Design: [SEE the attached screenshot OF THE HEADER — desktop and mobile]

You own: src/components/layout/Navbar/** and the `navigation` namespace in messages/{en,ua,ru}/navigation.json. Nothing else.

Requirements:

1. Keep `Navbar.tsx` a Server Component. The mobile menu is a client island in `components/MobileNav/` inside the Navbar folder — do not convert the whole header to `'use client'`.
2. Mobile menu uses the already-installed shadcn `sheet`. It must close on link click (an anchor jump does not unmount it), trap focus while open, close on Escape, and restore focus to the trigger.
3. Anchor links come from the SECTION_IDS registry in src/constants/sections.ts — never retype the id strings.
4. Add the primary CTA button ("Open Telegram bot" — key already exists as `navigation.openBot`) to both desktop and mobile. Its href comes from src/constants/links.ts. External link: `target="_blank"` + `rel="noopener noreferrer"`.
5. Remove `HealthBadge` from the header — it was scaffold proof-of-wiring, not product UI. Leave the component in place; just stop rendering it.
6. Active-section highlighting in the desktop nav is a nice-to-have. If you add it, it must be an IntersectionObserver-based client island scoped to the nav links only, and it must not cause a hydration mismatch.
7. Header is sticky with a backdrop blur (already implemented) — verify it does not overlap section content when an anchor is followed (the Section primitive sets scroll-margin; check the value matches the real header height).

Watch for: the burger button needs an accessible name (it is icon-only); the nav landmark needs to stay a single `<nav>`; ua/ru labels are longer than en — check the desktop nav does not wrap at 1024 px.
```

---

## T2 — Hero

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

Task: build the hero section — the first screen. Headline is "Trusted domains with a clean history" / subtitle "Ideal for Google & META." / primary CTA.

Design: [SEE the attached screenshot OF THE HERO]

You own: src/features/landing/hero/** and messages/{en,ua,ru}/landing-hero.json. Nothing else. Do not edit LandingPage.tsx — it already renders <Hero />.

Requirements:

1. Server Component. There is nothing interactive here except links — no `'use client'` at the section root.
2. Wrap in the shared `Section` primitive; use `SectionHeading` if it fits the design, otherwise compose locally — do not duplicate the primitive.
3. Primary CTA href from src/constants/links.ts (never hardcoded). If the design has a secondary CTA, point it at the pricing anchor via SECTION_IDS.
4. This is the LCP element of the page. Therefore:
   - If there is a hero image/illustration: `next/image` with `priority`, explicit `sizes`, and width/height (or `fill` + a sized parent) so there is zero CLS. Prefer an SVG/CSS-rendered decorative background over a raster where the design allows.
   - No scroll-reveal animation on the hero headline — do not delay the LCP paint. `Reveal` is for below-the-fold sections.
   - No client-side data fetching.
5. If the design has trust signals (domain count, uptime, "N+ domains sold"), model them as a typed array in `constants.ts` rendered in a loop — not as copy-pasted JSX. Numbers stay in the message catalog so they can be updated without a code change.
6. Responsive: the headline must not overflow at 360 px in Ukrainian (the longest of the three locales). Use `text-balance` on the headline and `text-pretty` on the subtitle.

Watch for: exactly one `<h1>` on the page and it lives here.
```

---

## T3 — Advantages

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

Task: build the "Advantages" section — why buying an aged domain from DWH HUB beats the alternatives (clean history, no bans, passes Google/META moderation, instant delivery, replacement guarantee, etc. — take the actual list from the design).

Design: [SEE the attached screenshot OF THE ADVANTAGES SECTION]

You own: src/features/landing/advantages/** and messages/{en,ua,ru}/landing-advantages.json. Nothing else.

Requirements:

1. Server Component. Wrap in the shared `Section` primitive with `id={SECTION_IDS.advantages}` — the navbar anchors to it.
2. Content is DATA, not markup. Define in `constants/advantages.ts`:

       type Advantage = { id: string; icon: LucideIcon; titleKey: string; descriptionKey: string };

   and render with a single `.map()`. One `AdvantageCard` component in `components/`. This is the shop-forward shape: when advantages become CMS-driven, only the constant is replaced.
3. Icons from `lucide-react` (installed). Icons are decorative — `aria-hidden`, and the meaning must live in the visible text, not the icon.
4. Wrap the grid in the shared `Reveal` primitive for a scroll-in animation, or reveal cards individually with a small stagger if the design implies it. Reduced-motion must be respected (the primitive handles it — do not reimplement).
5. Grid: 1 column mobile / 2 tablet / 3 desktop (adjust to the design). Cards in a row must be equal height — use grid, not flex-wrap with margins.

Watch for: card titles are headings — use a real heading level (`h3` under the section's `h2`), not a styled `<div>`.
```

---

## T4 — Compatibility

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

Task: build the "Compatibility" section — which ad platforms / trackers / niches the domains work with (Google Ads, META, TikTok, etc. — take the real list from the design). This is a credibility section: it answers "will this actually work for my traffic source?".

Design: [SEE the attached screenshot OF THE COMPATIBILITY SECTION]

You own: src/features/landing/compatibility/** and messages/{en,ua,ru}/landing-compatibility.json. Nothing else.

Requirements:

1. Server Component. `Section` primitive with `id={SECTION_IDS.compatibility}`.
2. Platform list as typed data in `constants/platforms.ts` with a stable `id` per platform — later these become filter facets in the catalog, so the ids must be meaningful slugs (`google-ads`, `meta`), not array indices.
3. Platform logos: put SVGs in `public/logos/` and render inline or via `next/image` with explicit dimensions. Third-party logos are brand assets — do not recolor them arbitrarily; if the design shows them monochrome, use CSS (`grayscale`/`opacity`) rather than editing the SVG source.
4. Each logo needs a text label or an `alt` — a wall of unlabeled logos is inaccessible and worthless for SEO.
5. If the design uses tabs/filters here, the tab list is the ONLY client island (`'use client'` inside `components/`), the section itself stays a Server Component, and the default tab's content must be in the server-rendered HTML.
6. Wrap in `Reveal`.

Watch for: platform names are proper nouns — they must NOT be translated. Keep them out of the message catalog (or store them as-is in all three locales) and translate only the surrounding copy.
```

---

## T5 — Profit comparison

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

Task: build the "Profit" section — a comparison showing the economics of using DWH HUB domains vs. the alternative (fresh/self-farmed domains): cost, ban rate, time-to-launch, effective ROI. The persuasion peak of the page.

Design: [SEE the attached screenshot OF THE PROFIT / COMPARISON SECTION]

You own: src/features/landing/profit/** and messages/{en,ua,ru}/landing-profit.json. Nothing else.

Requirements:

1. Server Component. `Section` primitive with `id={SECTION_IDS.profit}`.
2. Model the comparison as data, not as two hand-written columns:

       type ComparisonRow = { id: string; labelKey: string; ours: string; theirs: string; highlight?: boolean };

   Rendering from rows guarantees the two columns stay aligned and makes the responsive collapse trivial.
3. Semantics decide the markup: if it is genuinely tabular (rows × 2 columns), use a real `<table>` with `<caption>`/`<th scope>` (the shadcn `table` is installed) — screen readers and search engines both need the relationships. If the design is two feature cards side by side, use two cards. Do not fake a table with divs.
4. Responsive collapse: a 2-column comparison must not shrink into unreadable columns at 360 px. Either stack into two labelled cards or make the table horizontally scrollable inside its own `overflow-x-auto` container — the page body must never scroll horizontally.
5. Numbers, currency, and percentages go through next-intl's formatters (`useFormatter`), NOT string concatenation — `$1,000` / `1 000 $` differ per locale.
6. Do not let "ours" be marked as better by color alone (red/green). Add an icon or text label — color-blind users and grayscale printouts must still get the message.
7. If the design has an interactive calculator (spend/ROI slider), implement it as a client island in `components/`, keep the section a Server Component, compute in pure functions in `utils/`, and unit-test-shape the math (pure, no React) so it stays verifiable.

Watch for: this is the section most likely to grow into a real pricing calculator later — keep the math in `utils/` as pure functions, out of the component.
```

---

## T6 — Pricing

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

Task: build the "Pricing" section — the plans / domain packages with prices and a buy CTA.

Design: [SEE the attached screenshot OF THE PRICING SECTION]

You own: src/features/landing/pricing/** and messages/{en,ua,ru}/landing-pricing.json. Nothing else.

THIS IS THE SHOP-CRITICAL SECTION. Read § "The constraint that shapes every decision" in the delegation doc again before starting. In phase 2 these cards become server-fetched products. Build for that today:

1. Define the plan type in `types.ts` shaped like a future API DTO, not like the JSX you happen to need:

       type PricingPlan = {
         id: string;              // stable slug — future product id / catalog route param
         nameKey: string;
         priceAmount: number;     // a NUMBER, never a pre-formatted "$99" string
         currency: string;        // ISO 4217
         featureKeys: readonly string[];
         isFeatured?: boolean;
       };

   Static data lives in `constants/plans.ts` typed as `readonly PricingPlan[]`. When the backend lands, that constant is replaced by `productService.getProducts()` and the components do not change. Prices as numbers is the whole point — a `"$99"` string cannot be reformatted per locale, discounted, or summed in a cart.
2. Format prices with next-intl's `useFormatter().number(amount, { style: "currency", currency })`. Never concatenate a symbol.
3. Server Component + shadcn `card`. The featured plan is emphasized via a token-based style (border/glow), not a hardcoded color.
4. Every card's CTA href comes from src/constants/links.ts. Build it so the href can become per-plan later — e.g. a `getPlanHref(plan)` helper in `utils/` that today returns the shared Telegram URL and tomorrow returns `/catalog/${plan.id}`. One function to change.
5. If the design has a monthly/annual or volume toggle, that toggle is a client island in `components/`; the section stays a Server Component and the default state must be server-rendered.
6. Accessibility: price + currency must be readable as text (do not split "99" and "$" into visually-arranged spans that read as gibberish); feature lists are real `<ul>/<li>`.

Watch for: do not add a cart, do not add Zustand, do not create src/api/products. Just make sure none of that will require rewriting this section.
```

---

## T7 — FAQ

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

Task: build the FAQ section — expandable question/answer list (delivery time, replacement policy, payment methods, what "clean history" means, etc. — take the real questions from the design).

Design: [SEE the attached screenshot OF THE FAQ SECTION]

You own: src/features/landing/faq/** and messages/{en,ua,ru}/landing-faq.json. Nothing else.

Requirements:

1. Use the already-installed shadcn `accordion` (Radix — keyboard and ARIA correct out of the box). Do not hand-roll a details/summary toggle.
2. The accordion is a client component; keep the section wrapper itself a Server Component and put the accordion in `components/`.
3. Questions as typed data in `constants/faqItems.ts`: `{ id: string; questionKey: string; answerKey: string }[]`. Stable ids — they become the JSON-LD entity ids and potential deep-link anchors.
4. SEO — this is the point of an FAQ section: emit `FAQPage` JSON-LD structured data. Build the object from the SAME constants array and the resolved translations so the markup and the structured data can never drift. Render it with `<script type="application/ld+json">` from the Server Component; the JSON must be the localized copy for the active locale. Escape the JSON properly.
5. Answers may need inline links or bold — if so, use next-intl's rich text formatting (`t.rich`) with tags, NOT `dangerouslySetInnerHTML`.
6. Default state: all items collapsed unless the design says otherwise, and `type="single" collapsible` unless it shows multiple open at once.

Watch for: the JSON-LD `Question`/`Answer` text must match the visible text exactly — Google penalizes structured data that does not match rendered content.
```

---

## T8 — Final CTA

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

Task: build the closing CTA band — the last conversion push before the footer ("Choose a domain" / "Open the bot").

Design: [SEE the attached screenshot OF THE FINAL CTA SECTION]

You own: src/features/landing/cta/** and messages/{en,ua,ru}/landing-cta.json. Nothing else.

Requirements:

1. Server Component. `Section` primitive (no id needed — the navbar does not anchor here).
2. CTA href from src/constants/links.ts. External link gets `target="_blank"` + `rel="noopener noreferrer"` and its accessible name must make the destination obvious.
3. If the design shows a contact/lead form instead of (or beside) a button: React Hook Form + Zod per CLAUDE.md § Forms. The schema lives in `constants/schema.ts`, the type is derived with `z.infer` (never hand-written), the schema stores i18n message KEYS (e.g. "common:validation.required") resolved by the field component at render — schemas must not import i18n. There is no backend yet, so submit through a stub in `utils/` with a clear TODO shape, surface server errors via `setError("root", …)`, and show success/failure with `sonner`. Do not invent an endpoint.
4. Visual treatment (gradient/glow band) must use design tokens. If the design needs a gradient that has no token, add one to globals.css in BOTH `:root` and `.dark` and say so in your report — do not inline a hex.
5. Wrap in `Reveal`.

Watch for: if you add a form, it is the only client island — the section stays a Server Component.
```

---

## T9 — Footer

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

Task: build the site footer. A stub exists at src/components/layout/Footer/ and is already wired into the (marketing) layout.

Design: [SEE the attached screenshot OF THE FOOTER]

You own: src/components/layout/Footer/** and messages/{en,ua,ru}/footer.json. Nothing else.

Requirements:

1. Server Component. Semantic `<footer>` landmark.
2. Link groups as typed data in `constants.ts` — internal links use `Link` from `@/i18n/navigation` (locale-aware, keeps the /en|/ua|/ru prefix), section anchors use SECTION_IDS, external/social links use plain `<a>` with `rel="noopener noreferrer"`.
3. Social icons need accessible names — an icon-only link with no label is invisible to screen readers.
4. Copyright year computed at render (Server Component — no hydration mismatch risk, but do not hardcode 2026).
5. The footer must be ready for legal pages the shop will need (Terms, Privacy, Refund policy). Those routes do not exist yet: put the link entries in the constants with a clear TODO marker and render them only if a href is present — do NOT ship links to 404s.
6. Keep it a single grid that degrades to a stack at 360 px. Long ua/ru link labels must not overflow.

Watch for: the footer renders on every page including /not-found and /error — it must not depend on landing-only translations or data.
```

---

## T10 — SEO · a11y · perf · final polish

> **Run last, alone, after T1–T9 are merged.**

```
Read docs/landing-delegation.md § "Shared context" first — it is binding. Then read CLAUDE.md and AGENTS.md.

The landing sections are built by separate agents. Your job is the cross-cutting pass that no single section could do. Fix what you find; do not redesign sections.

## 1. SEO

- `generateMetadata` in src/app/[locale]/(marketing)/page.tsx: localized title/description from the message catalog, canonical URL, and `alternates.languages` hreflang entries for en/ua/ru + `x-default`. With `localePrefix: "always"` this is mechanical — get it exactly right, it is the main SEO payoff of the URL strategy.
- OpenGraph + Twitter card metadata, including a per-locale OG image (Next 16 supports generated OG images — check node_modules/next/dist/docs/ for the current API before writing it).
- `Organization` / `WebSite` JSON-LD in the locale layout. The FAQ section already emits `FAQPage` JSON-LD — verify there is exactly one of each and no duplication.
- `sitemap.ts` and `robots.ts` in src/app/ — the sitemap must list all three locale variants of every route with correct `alternates`.
- Verify exactly one `<h1>` per page and that heading levels never skip.

## 2. Accessibility (target WCAG 2.2 AA)

- Full keyboard pass: tab through the whole page including the mobile menu and the FAQ accordion. Visible focus on every interactive element. No keyboard traps.
- Add a skip-to-content link (sticky header makes this genuinely useful).
- Contrast check every text/background pair in BOTH themes. The dark palette is a seeded approximation — muted-foreground on card surfaces is the most likely failure. Report failures with measured ratios; fix by adjusting the token in globals.css, not by patching individual components.
- Verify landmarks: one `<header>`, one `<main>`, one `<footer>`, one `<nav>` per navigation region.
- Verify `prefers-reduced-motion` actually disables every animation added by the section agents.

## 3. Performance

- `npm run build` and read the route output. Flag any client bundle growth you cannot justify: every `'use client'` in the tree, and whether it could be pushed further down.
- Confirm the landing route is statically prerendered for all three locales (it should be — nothing on it is dynamic).
- Every image: correct `sizes`, modern format, explicit dimensions, `priority` ONLY on the hero LCP image.
- Fonts: verify no layout shift from font swap and that the Cyrillic subset is actually loading for ua/ru.
- The locale layout currently passes ALL messages to NextIntlClientProvider. Now that 8 namespaces exist, measure the serialized payload; if it is material, narrow it to the namespaces client components actually consume and document the tradeoff in CLAUDE.md.

## 4. Consistency pass

- Vertical rhythm between sections is uniform (all sections should be using the shared `Section` primitive — flag any that bypassed it).
- No duplicated component logic across sections that should have been lifted into features/landing/components/.
- No hardcoded colors, no hardcoded strings, no `any`, no cross-feature imports. Grep for them.
- All three locales have identical key sets in every namespace — write a quick check, do not eyeball it.
- Update CLAUDE.md and README.md if the structure drifted from what they describe.

## Done when

typecheck + lint + build clean; all three locales render correctly at 360/768/1280 in both themes; you have reported a list of what you fixed and anything you deliberately left for a follow-up.
```

---

## After the landing: the shop pass

Not part of this delegation, listed so the section agents' constraints make sense. Documented in `CLAUDE.md § Scaling to a Shop`:

`app/[locale]/(shop)/` route group · `src/api/{products,cart,orders,auth}` domains on the existing keys/service/hook pattern · catalog and product pages as Server Components with TanStack Query hydration · cart/checkout mutations as Zod-validated Server Actions · Zustand for cart state · per-product `generateMetadata` + `Product` JSON-LD.

The two files that carry the whole transition are `src/constants/links.ts` (CTA destinations) and `src/features/landing/pricing/constants/plans.ts` (static plans → fetched products).
